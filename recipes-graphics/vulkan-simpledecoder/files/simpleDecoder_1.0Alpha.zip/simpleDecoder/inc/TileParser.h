/*******************************************************************************
 Copyright �2016 Advanced Micro Devices, Inc. All rights reserved.

 Redistribution and use in source and binary forms, with or without 
 modification, are permitted provided that the following conditions are met:

 1   Redistributions of source code must retain the above copyright notice, 
 this list of conditions and the following disclaimer.
 2   Redistributions in binary form must reproduce the above copyright notice, 
 this list of conditions and the following disclaimer in the 
 documentation and/or other materials provided with the distribution.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE 
 LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
 THE POSSIBILITY OF SUCH DAMAGE.
 *******************************************************************************/

#ifndef _TILEPARSER_H_
#define _TILEPARSER_H_

#include <iostream>
#include <string>
#include "codec_api.h"
#include "vulkan.h"
#include "welsDecoderExt.h"
#include "IOInterface.h"

#include "vk_amd_video_decode_queue.h"


#define PROFILE_H264_CONSTRAINED  (1<<9)  // 8+1; constraint_set1_flag
#define PROFILE_H264_INTRA        (1<<11) // 8+3; constraint_set3_flag
#define PROFILE_H264_BASELINE             66
#define PROFILE_H264_CONSTRAINED_BASELINE (66|PROFILE_H264_CONSTRAINED)
#define PROFILE_H264_MAIN                 77
#define PROFILE_H264_EXTENDED             88
#define PROFILE_H264_HIGH                 100
#define PROFILE_H264_HIGH_10              110
#define PROFILE_H264_HIGH_10_INTRA        (110|PROFILE_H264_INTRA)
#define PROFILE_H264_HIGH_422             122
#define PROFILE_H264_HIGH_422_INTRA       (122|PROFILE_H264_INTRA)
#define PROFILE_H264_HIGH_444             144
#define PROFILE_H264_HIGH_444_PREDICTIVE  244
#define PROFILE_H264_HIGH_444_INTRA       (244|PROFILE_H264_INTRA)
#define PROFILE_H264_CAVLC_444            44
#define PROFILE_H264_MULTI_VIEW1          118   //MVC profile
#define PROFILE_H264_MULTI_VIEW2          128   //MVC profile

#define SPS_INFO_H264_EXTENSION_SUPPORT_FLAG_MASK                       (7)
#define SPS_INFO_H264_FIRST_PICTURE_AFTER_SEEK_FLAG_SHIFT               (6)
#define SPS_INFO_H264_GAPS_IN_FRAME_NUM_VALUE_ALLOWED_FLAG_SHIFT        (5)
#define SPS_INFO_H264_RESIDUAL_COLOUR_TRANSFORM_FLAG_SHIFT              (4)
#define SPS_INFO_H264_DELTA_PIC_ORDER_ALWAYS_ZERO_FLAG_SHIFT            (3)
#define SPS_INFO_H264_FRAME_MBS_ONLY_FLAG_SHIFT                         (2)
#define SPS_INFO_H264_MB_ADAPTIVE_FRAME_FIELD_FLAG_SHIFT                (1)
#define SPS_INFO_H264_DIRECT_8X8_INFERENCE_FLAG_SHIFT                   (0)


#define PPS_INFO_H264_ENTROPY_CODING_MODE_FLAG_SHIFT                    (8)
#define PPS_INFO_H264_PIC_ORDER_PRESENT_FLAG_SHIFT                      (7)
#define PPS_INFO_H264_WEIGHTED_PRED_FLAG_SHIFT                          (6)
#define PPS_INFO_H264_WEIGHTED_BIPRED_IDC_SHIFT                         (4)
#define PPS_INFO_H264_DEBLOCKING_FILTER_CONTROL_PRESENT_FLAG_SHIFT      (3)
#define PPS_INFO_H264_CONSTRAINED_INTRA_PRED_FLAG_SHIFT                 (2)
#define PPS_INFO_H264_REDUNDANT_PIC_CNT_PRESENT_FLAG_SHIFT              (1)
#define PPS_INFO_H264_TRANSFORM_8X8_MODE_FLAG_SHIFT                     (0)


#define MAXSLICES   64

#define SPS_NAL     7
#define PPS_NAL     8
#define I_FRAME_NAL 5
#define P_FRAME_NAL 1

//H264 standard mandates max frame size resulting in 0.5 compression ratio
#define MAXH264FRAMESIZE   ((4096*1024 * 3 / 2 )  / 2)
class h264Parse
{
private:
    unsigned char *readBuf;
    int pos;
    int readLen;
    std::string *fname;
    int64 fileSize;
    IOInterface *io; 
    unsigned int firstTimeFlag;
    unsigned int mPrevFrameNum;
    unsigned int mFrameBufOffset;
    unsigned int mFrameNum;
    SDecodingParam sDecParam;
    ISVCDecoder *mPDecoder;
    unsigned int mSpsId, mPpsId;
    unsigned char mNewSps, mNewPps;
    int h264GetProfile(int profileIdc);
    int decodePoc(unsigned int ppsId, unsigned int spsId, int *topPoc, int *bottomPoc);
    bool fillSpsPpsInfo(VkVideoDecodeH264PictureParametersBufferAMD *picParamBuffAmd, unsigned int spsId, unsigned int ppsId);
   


public:
    void *ioHndl;
    h264Parse(char *iname, IOInterface *user);
    bool parseSps(unsigned char *nalBuf, unsigned int bufSize);
    bool parsePps(unsigned char *nalBuf, unsigned int bufSize);
    bool parseSliceHeader(VkVideoDecodeH264PictureParametersBufferAMD *picParamBuffAmd,
        unsigned char *nalBuf, unsigned int bufSize, unsigned char *frameBuf, unsigned int *frameSize,
        unsigned char *frameEndDetected);
    bool init();
    ~h264Parse();
    void reset();
    int getNalUnit(unsigned char *nalBuf, int *nalLen); 
    
	// for POC mode 2:
	unsigned int mAbsFrameNum;
	int mExpectedPicOrderCnt, mPicOrderCntCycleCnt, mFrameNumInPicOrderCntCycle;
	unsigned int mPreviousFrameNum, mFrameNumOffset;
	int mExpectedDeltaPerPicOrderCntCycle;
	int mPreviousPOC, mThisPOC;
	int mPreviousFrameNumOffset;
	int mFramepoc,mTopPoc,mBottomPoc;
	unsigned int mLastHasMmco5;
	int mNalRefIdc;

};


#endif /* _TILEDPARSER_H_ */
