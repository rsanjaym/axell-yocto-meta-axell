/*******************************************************************************
Copyright �2016 Advanced Micro Devices, Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1   Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.
2   Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.
*******************************************************************************/
/**
********************************************************************************
* @file <vulkanDecodeEngine.cpp>
*
* @brief This file contains functions related to decoding of H264
*
********************************************************************************
*/
#include "vulkanDecodeEngine.h"

VulkanDecodeEngine::VulkanDecodeEngine()
{
    mDecodePipelineInitialized = false;
    mWidth = 0;
    mHeight = 0;
}
/**
*******************************************************************************
*  @fn     initDecodeEngine
*  @brief  This function initializes decoder, creates vulkan instance, device
*          command pool, command buffer etc
*
*  @param[in] width             : width of the video
*  @param[in] height            : Height of the video
*  @param[in] numTargetBuffers  : Number of target buffers used for decoding
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool VulkanDecodeEngine::initDecodeEngine(int width, int height,int numTargetBuffers)
{
    bool error;
    mWidth = width;
    mHeight = height;
    /**************************************************************************
    * creates vulkan instance and device                                      *
    **************************************************************************/
    error = VulkanDeviceImpl::init();
    CHECK_RESULT(error != true, "failed @ init() ");
    /**************************************************************************
    * Load vulkan decode related extension functions                          *
    **************************************************************************/
    error = loadVulkanExtFunction();
    CHECK_RESULT(error != true, "failed @ init() ");
    /**************************************************************************
    * Create command pool for decode queue                                    *
    **************************************************************************/
    error = VulkanDeviceImpl::createCommandPool(mDecodeQueueIndex, &mDecodeCommandPool);
    CHECK_RESULT(error != true, "failed @ createCommandPool() ");
    /**************************************************************************
    * Create Pipeline cache                                                   *
    **************************************************************************/
    error = VulkanDeviceImpl::createPipelineCache(&mPipelineCache);
    CHECK_RESULT(error != true, "failed @ createPipelineCache() ");
    /**************************************************************************
    * Create Command buffer                                                   *
    **************************************************************************/
    error = VulkanDeviceImpl::createCommandBuffer(mDecodeCommandPool, &mCmdBuffer);
    CHECK_RESULT(error != true, "failed @ createCommandBuffer() ");

    /**************************************************************************
    *  Create memory for decoder target buffer and video info buffer          *
    *  video info buffer will contain parsed pps and SPS header               *
    **************************************************************************/
    error = createVulkanDecodeBuffers(width, height, numTargetBuffers);
    CHECK_RESULT(error != true, "failed @ createVulkanDecodeBuffers() ");

    error = createVulkanDecodeInfoBuffersH264();
    CHECK_RESULT(error != true, "failed @ createVulkanDecodeInfoBuffersH264() ");

    return true;

}
/**
*******************************************************************************
*  @fn     createVulkanDecodeBuffers
*  @brief  This function creates 
*
*  @param[in] width             : width of the video
*  @param[in] height            : Height of the video
*  @param[in] numTargetBuffers  : Number of target buffers used for decoding
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool VulkanDecodeEngine::createVulkanDecodeBuffers(int width,int height,int numTargetBuffers)
{
    
    bool error = true;
    VkResult           vkres = VK_SUCCESS;

    CHECK_RESULT((numTargetBuffers > MAX_TARGET_QUEUE), "Number of target buffers is limited to %d ", MAX_TARGET_QUEUE);
    for (int i = 0; i < numTargetBuffers; i++)
    {
        VulkanDeviceImpl::createVulkanSurface(mDecoderTarget[i].mPSurfaceVk, VK_FORMAT_NV12_AMD, 2, width, height);
        CHECK_RESULT(error != true, "failed @ createVulkanSurface() ");

        unsigned int datasize = (width < 1080) ? MAX_BITSTREAM_DATA_SIZE_SD : MAX_BITSTREAM_DATA_SIZE_HD;
        VulkanDeviceImpl::createBuffer(datasize, mDecoderTarget[i].mBitstreamBuffer);
        CHECK_RESULT(error != true, "failed @ createBuffer() ");

        VkFenceCreateInfo fenceCreateInfo = {};
        fenceCreateInfo.sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO;

        vkres = vkCreateFence(mVulkanDevice,
            &fenceCreateInfo,
            nullptr,
            &mDecoderTarget[i].mWaitFence);
        CHECK_RESULT(vkres != VK_SUCCESS, "failed @ vkCreateFence() with error code %d", vkres);
        vkResetFences(mVulkanDevice, 1, &mDecoderTarget[i].mWaitFence);
    }
    return true;

}
/**
*******************************************************************************
*  @fn     createVulkanDecodeInfoBuffersH264
*  @brief  This function creates memory for decoder information buffer which 
*           contains SPS & PPS information which needs to be filled by application
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool VulkanDecodeEngine::createVulkanDecodeInfoBuffersH264()
{
    mNumVideoDecodeInfoBuffers = 1;

    memset(mPVideoDecodeInfoBuf, 0, sizeof(VkVideoDecodeInfoAMD*)*MAX_NUM_VIDEO_DECODE_INFO_BUF);
    // Allocate Vulkan pic params buffer
    mPPicParamsBuffer = new VkVideoDecodeInfoAMD;
    memset(mPPicParamsBuffer, 0, sizeof(VkVideoDecodeInfoAMD));

    mPPicParamsBuffer->infoType = VK_VIDEO_DECODE_INFO_TYPE_AMD_PICTURE_PARAMETERS;
    mPPicParamsBuffer->dataSize = sizeof(VkVideoDecodeH264PictureParametersBufferAMD);
    mPPicParamsBuffer->pData = new VkVideoDecodeH264PictureParametersBufferAMD;
    CHECK_RESULT(mPPicParamsBuffer->pData == NULL, "failed to create VkVideoDecodeH264PictureParametersBufferAMD");

    mPVideoDecodeInfoBuf[0] = mPPicParamsBuffer;
    return true;
}
/**
*******************************************************************************
*  @fn     beginDecodeFrame
*  @brief  This function copies H264 stream into vulkan input buffer and also 
*          copies the video info buffer
*
*  @param[in] input             : Input H264 frame buffer
*  @param[in] inputSize         : Size of the input frame buffer
*  @param[in] videoInfoBuf      : Video info buffer containing SPS and PPS info
*  @param[in] targetBuffId      : Target buffer ID to be decoded
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool VulkanDecodeEngine::beginDecodeFrame(unsigned char* input, unsigned int inputSize,
                                          VkVideoDecodeH264PictureParametersBufferAMD *videoInfoBuf,
                                          int targetBuffId)
{
    bool error = false;
    if (!mDecodePipelineInitialized)
    {
        error = createDecodeSession();
        CHECK_RESULT(error != true, "failed @ createDecodeSession()");
    }
    error = copyBitstream(input, inputSize, targetBuffId);
    CHECK_RESULT(error != true, "failed @ copyBitstream()");

    copyVideoInfoBuffer(videoInfoBuf);
    return true;
}
/**
*******************************************************************************
*  @fn     waitForDecodeToComplete
*  @brief  This function takes target buffer ID as input and waits for 
*          decoding to be completed for the target buffer
*
*  @param[in] targetBuffId      : Target buffer ID to be decoded
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool VulkanDecodeEngine::waitForDecodeToComplete(int targetBuffId)
{
    VkResult vkres = VK_SUCCESS;

    if (mDecoderTarget[targetBuffId].mIsFenceSubmitted)
    {
        do {
            vkres = vkWaitForFences(mVulkanDevice,
                1, // fenceCount
                &mDecoderTarget[targetBuffId].mWaitFence,
                VK_FALSE,
                2);
            if (vkres == VK_TIMEOUT)
            {
                SLEEP(2);
            }
            else if (vkres != VK_SUCCESS)
            {
                /**************************************************************
                * Decode error                                                *
                **************************************************************/
                printf("Error in decode\n");
                return false;
            }
        } while (vkres != VK_SUCCESS);

        mDecoderTarget[targetBuffId].mIsFenceSubmitted = false;
        
    }
    return true;
}
/**
*******************************************************************************
*  @fn     dumpOutput
*  @brief  This function takes target buffer ID as input and dumps the output 
*          into a file
*
*  @param[in/out] foutput      : pointer to the output file
*  @param[in] targetBuffId     : Target buffer ID to be decoded
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool VulkanDecodeEngine::dumpOutput(FILE *foutput,int targetBuffId)
{
    vulkanSurface *outputSurface = mDecoderTarget[targetBuffId].mPSurfaceVk;
    VkResult vkres;
    unsigned char* src_buffer = NULL;
    unsigned char* dst_buffer = (unsigned char*)malloc(sizeof(unsigned char*)*outputSurface->hSize);
    vkres = vkMapMemory(mVulkanDevice,
        outputSurface->hMemory,
        0,
        outputSurface->hSize,
        0,
        (void**)&src_buffer);

    int dstpitchW = mWidth;
    int dstheight = mHeight;
   
    {
        VkImageSubresource imageSubresource = {};
        VkSubresourceLayout subresourceLayout = {};
        imageSubresource.aspectMask = VK_IMAGE_ASPECT_Y_BIT_AMD;
        vkGetImageSubresourceLayout(mVulkanDevice, outputSurface->hImage, &imageSubresource, &subresourceLayout);

        int srcpitchW = (int)subresourceLayout.rowPitch;
        int srcwidth = mWidth;
        int srcheight = mHeight;

        unsigned char* pSrcY = (unsigned char*)src_buffer;
        unsigned char* pDstY = (unsigned char*)dst_buffer;
        for (int i = 0; i < srcheight; i++)
        {
            memcpy(pDstY, pSrcY, srcwidth);
            pSrcY += srcpitchW;
            pDstY += dstpitchW;
        }

        imageSubresource.aspectMask = VK_IMAGE_ASPECT_CBCR_AMD;
        vkGetImageSubresourceLayout(mVulkanDevice, outputSurface->hImage, &imageSubresource, &subresourceLayout);
        srcpitchW = (int)subresourceLayout.rowPitch;
        unsigned char* pSrcUV = (unsigned char*)src_buffer + (int)subresourceLayout.offset;
        unsigned char* pDstUV = (unsigned char*)dst_buffer + dstpitchW * dstheight;
        for (int i = 0; i < srcheight / 2; i++)
        {
            memcpy(pDstUV, pSrcUV, srcwidth);
            pSrcUV += srcpitchW;
            pDstUV += dstpitchW;
        }
        if (foutput)
        {
            fwrite(dst_buffer, (size_t)(srcwidth*srcheight*1.5), 1, foutput);
        }
    }
    vkUnmapMemory(mVulkanDevice, outputSurface->hMemory);

    free(dst_buffer);
    return true;

}
/**
*******************************************************************************
*  @fn     endDecodeFrame
*  @brief  This function submits the decode commands to the decode queue
*
*  @param[in] targetBuffId     : Target buffer ID to be decoded
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool VulkanDecodeEngine::endDecodeFrame(int targetBuffId)
{
    VkResult vkres = VK_SUCCESS;
    VkImage *vulkanImage = &mDecoderTarget[targetBuffId].mPSurfaceVk->hImage;
    VkBuffer *bitstreamBuf = &mDecoderTarget[targetBuffId].mBitstreamBuffer->mBuffer;
    /**************************************************************************
    * Record the command buffer ON                                            *
    **************************************************************************/
    VkCommandBufferBeginInfo cmdBufferBeginInfo = {};
    cmdBufferBeginInfo.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    cmdBufferBeginInfo.pInheritanceInfo = nullptr;
    cmdBufferBeginInfo.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;

    vkres = vkBeginCommandBuffer(mCmdBuffer, &cmdBufferBeginInfo);
    CHECK_RESULT(vkres != VK_SUCCESS, "failed @ vkBeginCommandBuffer() with error code %d", vkres);

    /**************************************************************************
    * Bind to the pipeline                                                    *
    **************************************************************************/
    vkCmdBindPipeline(mCmdBuffer, VK_PIPELINE_BIND_POINT_VIDEO_DECODE_AMD, mDecodePipeline);

    /**************************************************************************
    * Decode frame                                                            *
    **************************************************************************/

    VkVideoDecodeFrameInfoAMD decodeFrameInfo = {};
    decodeFrameInfo.srcBufferCount = 1;
    decodeFrameInfo.pSrcBuffers = mPVideoDecodeInfoBuf[0];
    decodeFrameInfo.dstImage = *vulkanImage;
    decodeFrameInfo.bitstreamBuffer = *bitstreamBuf;
    decodeFrameInfo.bitstreamDataSize = mDecoderTarget[targetBuffId].mBitstreamBuffer->mSize;
    decodeFrameInfo.sType = VK_STRUCTURE_TYPE_VIDEO_DECODE_FRAME_INFO_AMD;

    vkCmdDecodeVideoFrameAMD(mCmdBuffer, &decodeFrameInfo);

    /**************************************************************************
    * Record the command buffer OFF                                           *
    **************************************************************************/
    vkres = vkEndCommandBuffer(mCmdBuffer);
    CHECK_RESULT(vkres != VK_SUCCESS, "failed @ vkEndCommandBuffer() with error code %d", vkres);

    vkResetFences(mVulkanDevice, 1, &mDecoderTarget[targetBuffId].mWaitFence);

    /**************************************************************************
    * Execute the command buffer -> Submit                                    *
    **************************************************************************/
    VkSubmitInfo submitInfo = {};
    submitInfo.commandBufferCount = 1;
    submitInfo.pCommandBuffers = &mCmdBuffer;
    submitInfo.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;

    vkres = vkQueueSubmit(mQueues[mDecodeQueueIndex][0],
        1, //  submitCount 
        &submitInfo,
        mDecoderTarget[targetBuffId].mWaitFence);
    CHECK_RESULT(vkres != VK_SUCCESS, "failed @ vkQueueSubmit() with error code %d", vkres);

    mDecoderTarget[targetBuffId].mIsFenceSubmitted = true;
    return true;
}
/**
*******************************************************************************
*  @fn     copyBitstream
*  @brief  This function copies the bitstream to vulkan buffer
*
*  @param[in] input         : Input CPU owned frame buffer
*  @param[in] inputSize     : Input buffer size
*  @param[in] targetBuffId  : Target buffer ID to be decoded
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool VulkanDecodeEngine::copyBitstream(unsigned char* input,unsigned int inputSize,int targetBuffId)
{
    vulkanBuffer* buf = mDecoderTarget[targetBuffId].mBitstreamBuffer;
    
    buf->mSize = inputSize;

    VkResult vkres = VK_SUCCESS;
    char* dstBuffer = NULL;

    vkres = vkMapMemory(mVulkanDevice,
        buf->mMemory,
        0,
        buf->mSize,
        0,
        (void**)&dstBuffer);
    CHECK_RESULT(vkres != VK_SUCCESS, "failed @ vkMapMemory() with error code %d", vkres);
    CHECK_RESULT(dstBuffer == NULL,"Vulkan Bitstream buffer is empty");

    memcpy(dstBuffer, input, inputSize);

    vkUnmapMemory(mVulkanDevice, buf->mMemory);

    return true;
}
/**
*******************************************************************************
*  @fn     copyVideoInfoBuffer
*  @brief  This function fills video info buffer which contains sps and pps info
*
*  @param[in] videoInfoBuf  : Video info buffer
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool VulkanDecodeEngine::copyVideoInfoBuffer(VkVideoDecodeH264PictureParametersBufferAMD *videoInfoBuf)
{
    VkVideoDecodeH264PictureParametersBufferAMD *vkPicParams = (VkVideoDecodeH264PictureParametersBufferAMD*)mPPicParamsBuffer->pData;
    memset(vkPicParams, 0, sizeof(VkVideoDecodeH264PictureParametersBufferAMD));

    vkPicParams->bitDepthChromaMinus8 = videoInfoBuf->bitDepthChromaMinus8;
    vkPicParams->bitDepthLumaMinus8 = videoInfoBuf->bitDepthLumaMinus8;
    vkPicParams->chromaFormat = videoInfoBuf->chromaFormat;
    vkPicParams->chromaQpIndexOffset = videoInfoBuf->chromaQpIndexOffset;
    vkPicParams->currFieldOrderCntList[0] = videoInfoBuf->currFieldOrderCntList[0];
    vkPicParams->currFieldOrderCntList[1] = videoInfoBuf->currFieldOrderCntList[1];
    vkPicParams->currPicRefFrameNum = videoInfoBuf->currPicRefFrameNum;

    vkPicParams->decodedPicIdx = videoInfoBuf->decodedPicIdx;
    for (int i = 0; i<16; i++)
    {
        vkPicParams->refFrameList[i] = 0xFF;
        vkPicParams->frameNumList[i] = 0x0;
        vkPicParams->fieldOrderCntList[i][0] = 0;
        vkPicParams->fieldOrderCntList[i][1] = 0;
    }

    vkPicParams->frameNum = videoInfoBuf->frameNum;

    vkPicParams->level = videoInfoBuf->level;
    vkPicParams->log2MaxFrameNumMinus4 = videoInfoBuf->log2MaxFrameNumMinus4;
    vkPicParams->log2MaxPicOrderCntLsbMinus4 = videoInfoBuf->log2MaxPicOrderCntLsbMinus4;
    vkPicParams->numRefFrames = videoInfoBuf->numRefFrames;

    vkPicParams->numRefIdxl0ActiveMinus1 = videoInfoBuf->numRefIdxl0ActiveMinus1;
    vkPicParams->numRefIdxl1ActiveMinus1 = videoInfoBuf->numRefIdxl1ActiveMinus1;
    vkPicParams->numSliceGroupsMinus1 = videoInfoBuf->numSliceGroupsMinus1;
    vkPicParams->picInitQpMinus26 = videoInfoBuf->picInitQpMinus26;

    vkPicParams->picInitQsMinus26 = videoInfoBuf->picInitQsMinus26;
    vkPicParams->picOrderCntType = videoInfoBuf->picOrderCntType;
    vkPicParams->ppsInfoFlags = videoInfoBuf->ppsInfoFlags;
    vkPicParams->profile = videoInfoBuf->profile;

    for (int i = 0; i<6; i++)
    {
        for (int j = 0; j<16; j++)
        {
            vkPicParams->scalingList4x4[i][j] = videoInfoBuf->scalingList4x4[i][j];
        }
    }

    for (int i = 0; i<2; i++)
    {
        for (int j = 0; j<64; j++)
        {
            vkPicParams->scalingList8x8[i][j] = videoInfoBuf->scalingList8x8[i][j];
        }
    }

    vkPicParams->secondChromaQpIndexOffset = videoInfoBuf->secondChromaQpIndexOffset;
    vkPicParams->sliceGroupChangeRateMinus1 = videoInfoBuf->sliceGroupChangeRateMinus1;
    vkPicParams->sliceGroupMapType = videoInfoBuf->sliceGroupMapType;
    vkPicParams->spsInfoFlags = videoInfoBuf->spsInfoFlags;

    return true;
}
/**
*******************************************************************************
*  @fn     loadVulkanExtFunction
*  @brief  Load vulkan decode extension functions
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool VulkanDecodeEngine::loadVulkanExtFunction()
{

    GET_INSTANCE_ENTRYPOINT(mVulkanInstance, vkGetPhysicalDeviceSurfaceSupportKHR);
    GET_INSTANCE_ENTRYPOINT(mVulkanInstance, vkGetPhysicalDeviceSurfaceCapabilitiesKHR);
    GET_INSTANCE_ENTRYPOINT(mVulkanInstance, vkGetPhysicalDeviceSurfaceFormatsKHR);
    GET_INSTANCE_ENTRYPOINT(mVulkanInstance, vkGetPhysicalDeviceSurfacePresentModesKHR);

    GET_DEVICE_ENTRYPOINT(mVulkanDevice, vkCreateSwapchainKHR);
    GET_DEVICE_ENTRYPOINT(mVulkanDevice, vkDestroySwapchainKHR);
    GET_DEVICE_ENTRYPOINT(mVulkanDevice, vkGetSwapchainImagesKHR);
    GET_DEVICE_ENTRYPOINT(mVulkanDevice, vkAcquireNextImageKHR);
    GET_DEVICE_ENTRYPOINT(mVulkanDevice, vkQueuePresentKHR);

    GET_DEVICE_ENTRYPOINT(mVulkanDevice, vkCreateVideoDecodePipelinesAMD);
    GET_DEVICE_ENTRYPOINT(mVulkanDevice, vkCmdBeginVideoDecodeAMD);
    GET_DEVICE_ENTRYPOINT(mVulkanDevice, vkCmdDecodeVideoFrameAMD);
    GET_DEVICE_ENTRYPOINT(mVulkanDevice, vkCmdEndVideoDecodeAMD);
    
    return true;
}
/**
*******************************************************************************
*  @fn     createDecodeSession
*  @brief  This function creates dummy pipeline for the first frame of the stream
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool VulkanDecodeEngine::createDecodeSession()
{
    VkResult vkres = VK_SUCCESS;

    /*************************************************************************
    * Create AMD Decode pipeline                                             *
    *************************************************************************/
    CHECK_RESULT((vkCreateVideoDecodePipelinesAMD == nullptr ||
                  vkCmdBeginVideoDecodeAMD == nullptr ||
                  vkCmdDecodeVideoFrameAMD == nullptr ||
                  vkCmdEndVideoDecodeAMD == nullptr), "AMD decode externsions are not loaded");
        
    VkVideoDecodePipelineCreateInfoAMD dummyPipelineCreateInfo = {};
    dummyPipelineCreateInfo.sType = VK_STRUCTURE_TYPE_VIDEO_DECODE_PIPELINE_CREATE_INFO_AMD;
    dummyPipelineCreateInfo.pNext = NULL;
    dummyPipelineCreateInfo.videoCodec = VK_VIDEO_DECODE_CODEC_AMD_H264;
    dummyPipelineCreateInfo.outputFormat = VK_FORMAT_NV12_AMD;
    dummyPipelineCreateInfo.frameSize.width = mWidth;
    dummyPipelineCreateInfo.frameSize.height = mHeight;
    dummyPipelineCreateInfo.maxDecodePictureBufferFrameCount = MAX_TARGET_QUEUE;

    vkres = vkCreateVideoDecodePipelinesAMD(mVulkanDevice,
        mPipelineCache,
        1,
        &dummyPipelineCreateInfo,
        nullptr,
        &mDecodePipeline);
    CHECK_RESULT(vkres != VK_SUCCESS, "failed to create Video decode pipeline AMD, Error code = %d",vkres);

    /*************************************************************************
    * Record the command buffer ON                                           *
    *************************************************************************/
    VkCommandBufferBeginInfo cmdBufferBeginInfo = {};
    cmdBufferBeginInfo.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    cmdBufferBeginInfo.pInheritanceInfo = nullptr;
    cmdBufferBeginInfo.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;

    vkres = vkBeginCommandBuffer(mCmdBuffer, &cmdBufferBeginInfo);
    CHECK_RESULT(vkres != VK_SUCCESS, "failed @ vkBeginCommandBuffer, Error code = %d", vkres);

    vkCmdBindPipeline(mCmdBuffer, VK_PIPELINE_BIND_POINT_VIDEO_DECODE_AMD, mDecodePipeline);

    /*************************************************************************
    * Open AMD Decode session                                                *
    *************************************************************************/
    VkVideoDecodeBeginInfoAMD decodeBeginInfo = {};
    vkCmdBeginVideoDecodeAMD(mCmdBuffer, &decodeBeginInfo);
    CHECK_RESULT(vkres != VK_SUCCESS, "failed @ vkCmdBeginVideoDecodeAMD, Error code = %d", vkres);

    /*************************************************************************
    * Record the command buffer OFF                                          *
    *************************************************************************/
    vkres = vkEndCommandBuffer(mCmdBuffer);
    CHECK_RESULT(vkres != VK_SUCCESS, "failed @ vkEndCommandBuffer, Error code = %d", vkres);

    /*************************************************************************
    * Execute the command buffer -> Submit                                   *
    *************************************************************************/
    VkSubmitInfo submitInfo = {};
    submitInfo.commandBufferCount = 1;
    submitInfo.pCommandBuffers = &mCmdBuffer;
    submitInfo.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;

    vkres = vkQueueSubmit(mQueues[mDecodeQueueIndex][0],
        1, //  submitCount 
        &submitInfo,
        nullptr);
    CHECK_RESULT(vkres != VK_SUCCESS, "failed @ vkQueueSubmit, Error code = %d", vkres);

    mDecodePipelineInitialized = true;

    return true;
}
/**
*******************************************************************************
*  @fn     destroy
*  @brief  This function Releases the resources used by the decoder
*
*  @param[in] numTargetBuffers  : Number of target buffers used for decoding 
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool VulkanDecodeEngine::destroy(int numTargetBuffers)
{
    bool error;
    CHECK_RESULT((numTargetBuffers > MAX_TARGET_QUEUE), "Number of target buffers is limited to %d ", MAX_TARGET_QUEUE);

    for (int i = 0; i < numTargetBuffers; i++)
    {

        error = VulkanDeviceImpl::releaseSurface(mDecoderTarget[i].mPSurfaceVk);
        CHECK_RESULT(error != true, "failed while releasing the surface");

        error = VulkanDeviceImpl::releaseBuffer(mDecoderTarget[i].mBitstreamBuffer);
        CHECK_RESULT(error != true, "failed while releasing the surface");
    }

    error = VulkanDeviceImpl::releaseResource();
    CHECK_RESULT(error != true, "failed while releasing the device and instance");

    return true;
}