/*
 ***********************************************************************************************************************
 *
 *  Trade secret of Advanced Micro Devices, Inc.
 *  Copyright (c) 2014-2016, Advanced Micro Devices, Inc., (unpublished)
 *
 *  All rights reserved. This notice is intended as a precaution against inadvertent publication and does not imply
 *  publication or any waiver of confidentiality. The year included in the foregoing notice is the year of creation of
 *  the work.
 *
 **********************************************************************************************************************/
/**
 **********************************************************************************************************************
 * @file  vk_amd_video_decode_queue.h
 * @brief Temporary internal header for UVD extension. Should be removed once the extension is published and the API
 *        gets included in the official Vulkan header.
 **********************************************************************************************************************
 */
#ifndef VK_AMD_VIDEO_DECODE_QUEUE_H_
#define VK_AMD_VIDEO_DECODE_QUEUE_H_

#include "vk_internal_ext_helper.h"

#define VK_AMD_VIDEO_DECODE_QUEUE_SPEC_VERSION              1
#define VK_AMD_VIDEO_DECODE_QUEUE_EXTENSION_NAME            "VK_AMD_video_decode_queue"

#define VK_AMD_VIDEO_DECODE_QUEUE_EXTENSION_NUMBER          25

#define VK_AMD_VIDEO_DECODE_QUEUE_ENUM(type, offset) \
    VK_EXTENSION_ENUM(VK_AMD_VIDEO_DECODE_QUEUE_EXTENSION_NUMBER, type, offset)

typedef enum VkVideoDecodeCodecAMD
{
    VK_VIDEO_DECODE_CODEC_AMD_H264 = 0,
    VK_VIDEO_DECODE_CODEC_AMD_H264_MVC = 1,
    VK_VIDEO_DECODE_CODEC_AMD_BEGIN_RANGE = VK_VIDEO_DECODE_CODEC_AMD_H264,
    VK_VIDEO_DECODE_CODEC_AMD_END_RANGE = VK_VIDEO_DECODE_CODEC_AMD_H264_MVC,
    VK_VIDEO_DECODE_CODEC_AMD_RANGE_SIZE = (VK_VIDEO_DECODE_CODEC_AMD_H264_MVC - VK_VIDEO_DECODE_CODEC_AMD_H264 + 1),
    VK_VIDEO_DECODE_CODEC_AMD_MAX_ENUM = 0x7FFFFFFF
} VkVideoDecodeCodecAMD;

typedef enum VkVideoDecodeInfoTypeAMD {
    VK_VIDEO_DECODE_INFO_TYPE_AMD_PICTURE_PARAMETERS = 0,
    VK_VIDEO_DECODE_INFO_TYPE_AMD_MVC_VIEW_INFO = 1,
    VK_VIDEO_DECODE_INFO_TYPE_AMD_BEGIN_RANGE = VK_VIDEO_DECODE_INFO_TYPE_AMD_PICTURE_PARAMETERS,
    VK_VIDEO_DECODE_INFO_TYPE_AMD_END_RANGE = VK_VIDEO_DECODE_INFO_TYPE_AMD_MVC_VIEW_INFO,
    VK_VIDEO_DECODE_INFO_TYPE_AMD_RANGE_SIZE = (VK_VIDEO_DECODE_INFO_TYPE_AMD_MVC_VIEW_INFO - VK_VIDEO_DECODE_INFO_TYPE_AMD_PICTURE_PARAMETERS + 1),
    VK_VIDEO_DECODE_INFO_TYPE_AMD_MAX_ENUM = 0x7FFFFFFF
} VkVideoDecodeInfoTypeAMD;

struct VkVideoDecodePipelineCreateInfoAMD
{
    VkStructureType                             sType;
    const void*                                 pNext;
    VkVideoDecodeCodecAMD                       videoCodec;
    VkFormat                                    outputFormat;
    VkExtent2D                                  frameSize;
    uint32_t                                    maxDecodePictureBufferFrameCount;
    float                                       frameRate;
    uint32_t                                    bitrate;
};

struct VkVideoDecodeBeginInfoAMD
{
    VkStructureType                             sType;
    const void*                                 pNext;
};

struct VkVideoDecodeInfoAMD
{
    VkVideoDecodeInfoTypeAMD                    infoType;
    VkDeviceSize                                dataSize;
    const void*                                 pData;
};

struct VkVideoDecodeFrameInfoAMD
{
    VkStructureType                             sType;
    const void*                                 pNext;
    uint32_t                                    srcBufferCount;
    const VkVideoDecodeInfoAMD*                 pSrcBuffers;
    VkBuffer                                    bitstreamBuffer;
    VkDeviceSize                                bitstreamDataSize;
    VkImage                                     dstImage;
};

typedef VkResult (VKAPI_PTR *PFN_vkCreateVideoDecodePipelinesAMD)(
    VkDevice                                    device,
    VkPipelineCache                             pipelineCache,
    uint32_t                                    createInfoCount,
    const VkVideoDecodePipelineCreateInfoAMD*   pCreateInfos,
    const VkAllocationCallbacks*                pAllocator,
    VkPipeline*                                 pPipelines);

VKAPI_ATTR VkResult VKAPI_CALL vkCreateVideoDecodePipelinesAMD(
    VkDevice                                    device,
    VkPipelineCache                             pipelineCache,
    uint32_t                                    createInfoCount,
    const VkVideoDecodePipelineCreateInfoAMD*   pCreateInfos,
    const VkAllocationCallbacks*                pAllocator,
    VkPipeline*                                 pPipelines);

typedef void (VKAPI_PTR *PFN_vkCmdBeginVideoDecodeAMD)(
    VkCommandBuffer                             cmdBuffer,
    const VkVideoDecodeBeginInfoAMD*            pBeginInfo);

VKAPI_ATTR void VKAPI_CALL vkCmdBeginVideoDecodeAMD(
    VkCommandBuffer                             cmdBuffer,
    const VkVideoDecodeBeginInfoAMD*            pBeginInfo);

typedef void (VKAPI_PTR *PFN_vkCmdDecodeVideoFrameAMD)(
    VkCommandBuffer                             cmdBuffer,
    const VkVideoDecodeFrameInfoAMD*            pDecodeInfo);

VKAPI_ATTR void VKAPI_CALL vkCmdDecodeVideoFrameAMD(
    VkCommandBuffer                             cmdBuffer,
    const VkVideoDecodeFrameInfoAMD*            pDecodeInfo);

typedef void (VKAPI_PTR *PFN_vkCmdEndVideoDecodeAMD)(
    VkCommandBuffer                             cmdBuffer);

VKAPI_ATTR void VKAPI_CALL vkCmdEndVideoDecodeAMD(
    VkCommandBuffer                             cmdBuffer);

#define VK_STRUCTURE_TYPE_VIDEO_DECODE_PIPELINE_CREATE_INFO_AMD VK_AMD_VIDEO_DECODE_QUEUE_ENUM(VkStructureType, 0)
#define VK_STRUCTURE_TYPE_VIDEO_DECODE_BEGIN_INFO_AMD           VK_AMD_VIDEO_DECODE_QUEUE_ENUM(VkStructureType, 1)
#define VK_STRUCTURE_TYPE_VIDEO_DECODE_FRAME_INFO_AMD           VK_AMD_VIDEO_DECODE_QUEUE_ENUM(VkStructureType, 2)

#define VK_PIPELINE_BIND_POINT_VIDEO_DECODE_AMD                 VK_AMD_VIDEO_DECODE_QUEUE_ENUM(VkPipelineBindPoint, 0)

#define VK_FORMAT_FEATURE_VIDEO_DECODE_DST_BIT_AMD              VK_EXTENSION_BIT(VkFormatFeatureFlagBits, 15)

#define VK_QUEUE_VIDEO_DECODE_BIT_AMD                           VK_EXTENSION_BIT(VkQueueFlagBits, 5)

// H264 codec specific data structures

typedef enum VkVideoDecodeH264SPSInfoFlagBitsAMD {
    VK_VIDEO_DECODE_H264_SPS_INFO_DIRECT_8X8_INFERENCE_BIT = 0x00000001,
    VK_VIDEO_DECODE_H264_SPS_INFO_MB_ADAPTIVE_FRAME_FIELD_BIT = 0x00000002,
    VK_VIDEO_DECODE_H264_SPS_INFO_FRAME_MBS_ONLY_BIT = 0x00000004,
    VK_VIDEO_DECODE_H264_SPS_INFO_DELTA_PIC_ORDER_ALWAYS_ZERO_BIT = 0x00000008,
    VK_VIDEO_DECODE_H264_SPS_INFO_RESIDUAL_COLOUR_TRANSFORM_BIT = 0x00000010,
    VK_VIDEO_DECODE_H264_SPS_INFO_GAPS_IN_FRAME_NUM_VALUE_ALLOWED_BIT = 0x00000020,
    VK_VIDEO_DECODE_H264_SPS_INFO_FIRST_PICTURE_AFTER_SEEK_BIT = 0x00000040,
    VK_VIDEO_DECODE_H264_SPS_INFO_FLAG_BITS_MAX_ENUM = 0x7FFFFFFF
} VkVideoDecodeH264SPSInfoFlagBitsAMD;
typedef VkFlags VkVideoDecodeH264SPSInfoFlagsAMD;

typedef enum VkVideoDecodeH264PPSInfoFlagBitsAMD {
    VK_VIDEO_DECODE_H264_PPS_TRANSFORM_8X8_MODE_BIT = 0x00000001,
    VK_VIDEO_DECODE_H264_PPS_REDUNDANT_PIC_CNT_PRESENT_BIT = 0x00000002,
    VK_VIDEO_DECODE_H264_PPS_CONSTRAINED_INTRA_PRED_BIT = 0x00000004,
    VK_VIDEO_DECODE_H264_PPS_DEBLOCKING_FILTER_CONTROL_PRESENT_BIT = 0x00000008,
    VK_VIDEO_DECODE_H264_PPS_WEIGHTED_BIPRED_IDC_BITS = 0x00000030,
    VK_VIDEO_DECODE_H264_PPS_WEIGHTED_PRED_BIT = 0x00000040,
    VK_VIDEO_DECODE_H264_PPS_PIC_ORDER_PRESENT_BIT = 0x00000080,
    VK_VIDEO_DECODE_H264_PPS_ENTROPY_CODING_MODE_BIT = 0x00000100,
    VK_VIDEO_DECODE_H264_PPS_INFO_FLAG_BITS_MAX_ENUM = 0x7FFFFFFF
} VkVideoDecodeH264PPSInfoFlagBitsAMD;
typedef VkFlags VkVideoDecodeH264PPSInfoFlagsAMD;

struct VkVideoDecodeH264PictureParametersBufferAMD
{
    uint32_t                                    profile;
    uint32_t                                    level;

    VkVideoDecodeH264SPSInfoFlagsAMD            spsInfoFlags;
    VkVideoDecodeH264PPSInfoFlagsAMD            ppsInfoFlags;
    uint8_t                                     chromaFormat;
    uint8_t                                     bitDepthLumaMinus8;
    uint8_t                                     bitDepthChromaMinus8;
    uint8_t                                     log2MaxFrameNumMinus4;

    uint8_t                                     picOrderCntType;
    uint8_t                                     log2MaxPicOrderCntLsbMinus4;
    uint8_t                                     numRefFrames;
    uint8_t                                     reserved8bit;

    int8_t                                      picInitQpMinus26;
    int8_t                                      picInitQsMinus26;
    int8_t                                      chromaQpIndexOffset;
    int8_t                                      secondChromaQpIndexOffset;

    uint8_t                                     numSliceGroupsMinus1;
    uint8_t                                     sliceGroupMapType;
    uint8_t                                     numRefIdxl0ActiveMinus1;
    uint8_t                                     numRefIdxl1ActiveMinus1;

    uint16_t                                    sliceGroupChangeRateMinus1;
    uint16_t                                    reserved16bit1;

    // The scaling list in zig-zag scan order
    uint8_t                                     scalingList4x4[6][16];
    uint8_t                                     scalingList8x8[2][64];

    // frame_num_list and field_order_cnt_list can be used to identify each
    // reference frame. They are unique and will not change for all the slices of
    // the same frame. Bit 31 of the frame_num_list will be used to convey
    // the AssociatedFlag info.
    uint32_t                                    frameNum;
    uint32_t                                    frameNumList[16];
    int32_t                                     currFieldOrderCntList[2];
    int32_t                                     fieldOrderCntList[16][2];

    // decode surface index provided by player
    uint32_t                                    decodedPicIdx;

    // number of reference frame of the current picture.
    uint32_t                                    currPicRefFrameNum;

    // ref frame index and long term reference flag (this indicates which entry is valid)
    uint8_t                                     refFrameList[16];
};

struct VkVideoDecodeH264MVCElementAMD
{
    uint16_t                                    viewOrderIndex;                 // VOIdx
    uint16_t                                    viewId;                         // view_id[VOIdx]
    uint16_t                                    numOfAnchorRefsInL0;            // number of anchor inter-views in l0
    uint16_t                                    viewIdOfAnchorRefsInL0[15];     // anchor inter-views in l0
    uint16_t                                    numOfAnchorRefsInL1;            // number of anchor inter views in l1
    uint16_t                                    viewIdOfAnchorRefsInL1[15];     // anchor inter-views in l1
    uint16_t                                    numOfNonAnchorRefsInL0;         // number of non anchor inter-views in l0
    uint16_t                                    viewIdOfNonAnchorRefsInL0[15];  // non anchor inter-views in l0
    uint16_t                                    numOfNonAnchorRefsInL1;         // number of non anchor inter-views in l1
    uint16_t                                    viewIdOfNonAnchorRefsInL1[15];  // non anchor inter-views in l1
};

struct VkVideoDecodeH264MVCViewInfoBufferAMD
{
    uint32_t                                    numViews;       // number of coded views
    uint32_t                                    viewId0;        // view_id for the baseview
    VkVideoDecodeH264MVCElementAMD              mvcElements[1]; // allocate “numViews – 1” elements here
};

#endif /* VK_AMD_VIDEO_DECODE_QUEUE_H_ */
