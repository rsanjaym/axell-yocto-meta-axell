/*******************************************************************************
 Copyright �2014 Advanced Micro Devices, Inc. All rights reserved.

 Redistribution and use in source and binary forms, with or without 
 modification, are permitted provided that the following conditions are met:

 1   Redistributions of source code must retain the above copyright notice, 
 this list of conditions and the following disclaimer.
 2   Redistributions in binary form must reproduce the above copyright notice, 
 this list of conditions and the following disclaimer in the 
 documentation and/or other materials provided with the distribution.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE 
 LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
 THE POSSIBILITY OF SUCH DAMAGE.
 *******************************************************************************/
/**
 ********************************************************************************
 * @file <IOInterface.h>
 *
 * @brief Defines the functions used for input and output interfacing
 *
 ********************************************************************************
 */

#ifndef _IOINTERFACE_H_
#define _IOINTERFACE_H_
#include "Typedef.h"

typedef enum _AMDIO_MODE
{
    AMD_READ = 0,
    AMD_WRITE,
    AMD_APPEND
}AMDIO_MODE;

typedef enum _AMDIO_ORIGIN
{
    AMD_SEEK_SET = 0,
    AMD_SEEK_CUR,
    AMD_SEEK_END
}AMDIO_ORIGIN;

#define EOD -1

/*! \class IOInterface
    \brief Pure virtual methods for input and  output handling

    This class contains all the I/O interface functions 
 */
class IOInterface
{
public:
    /**
    *******************************************************************************
    * @fn open
    * @brief Function to open a flie in write mode
    *
    * @param[in] sourceName : int8 * :   Name of the source being opened
    * @param[in] ioMode : AMDIO_MODE :   mode of the I/O device to open
    *
    * @return void * I/O device handle
    *******************************************************************************
    */
    virtual void *open(int8 *sourceName, AMDIO_MODE ioMode) = 0;

    /*******************************************************************************
	* @fn readNalu
	* @brief Function to read one nal unit from I/O Device
	*
	* @param[in] pHandle : void * :  amd I/O handle
	* @param[in] nalBuf : void * :     pointer to the nal buffer
	* @param[inout] size : int32 * :   size of allocated nal buffer in bytes as input
	* 								   size of nal-buffer in bytes as output
	*
	* @returns nal_unit_type
	*******************************************************************************
	*/
	virtual int32 readNalu(void *pHandle, uint8 *nalBuf, int32 *nalSize) = 0;

    /**
    *******************************************************************************
    * @fn seek
    * @brief Function to seek from I/O Device origin
    *
    * @param[in] pHandle : void * :  amd I/O handle
    * @param[in] offset : int64 :   Number of bytes to offset from origin.
    * @param[in] origin : AMDIO_ORIGIN :    Position used as reference for the offset. 
    *
    * @return If successful, the function returns zero.
    * Otherwise, it returns non-zero value.
    *******************************************************************************
    */
    virtual int32 seek(void *pHandle, int64  offset, AMDIO_ORIGIN ioOrigin) = 0;

    /**
    *******************************************************************************
    * @fn eod
    * @brief Checks whether the end-of-data indicator associated with I/O device
    *
    * @param[in] pHandle : void * :  amd I/O handle
    *
    * @return A non-zero value is returned in the case that the end-of-data indicator
    *associated with the I/O device is set.Otherwise, zero is returned.
    *******************************************************************************
    */
    virtual int32 eod(void *pHandle) = 0;

    /**
    *******************************************************************************
    * @fn close
    * @brief Function to close the I/O device
    *
    * @param[in] pHandle : void * :  amd I/O handle
    *
    * @return If the I/O device  is successfully closed, a zero value is returned.
    *  On failure, EOD is returned.
    *******************************************************************************
    */
    virtual int32 close(void *pHandle) = 0;
};

#endif /* _AMDINTERFACE_H_ */
