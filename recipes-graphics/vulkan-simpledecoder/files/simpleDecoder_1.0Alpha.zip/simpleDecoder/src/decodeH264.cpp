/*******************************************************************************
Copyright �2016 Advanced Micro Devices, Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1   Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.
2   Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.
*******************************************************************************/
/**
********************************************************************************
* @file <decodeH264.cpp>
*
* @brief main file for h264 decoder application 
*
********************************************************************************
*/

#include "TileParser.h"
#include "amdInterface.h"

#include "decoder_context.h"
#include "vulkanDecodeEngine.h"

bool parseAndDecodeFrame(h264Parse *pParser, VulkanDecodeEngine *pVulkanDecode, FILE *foutput);

/**
*******************************************************************************
*  @fn     usage
*  @brief  prints the usage information
*
*  @param[in] program  : program
*
*  @return void
*******************************************************************************
*/
void usage(char *program)
{
    std::cout << "Usage...\n";
    std::cout << program
        << " \n\t-H (help)\n\t-i [input H264 file] \n\t-o [output nv12 file] \n\t-w [N] \n\t-h [N] \n";
    std::cout
        << "Example : .exe -i gbody.h264 -o outputfile.yuv -w 1024 -h 1024 \n";
}

/**
*******************************************************************************
*  @fn     parseArguments
*  @brief  This function parses the command line arguments
*
*  @param[in] argc              : Number of arguments
*  @param[in] argv              : Pointer to the
*  @param[in/out] inputFile     : Input file
*  @param[in/out] outputFile    : Output file
*  @param[in/out] width         : width of input h264 video
*  @param[in/out] height        : height of input h264 video
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool parseArguments(int argc, char* argv[], char *inputFile, char *outputFile,
    unsigned int *width, unsigned int *height)
{
    /***************************************************************************
    *  Processing the command line and configuration file                      *
    ***************************************************************************/
    int index = 0;
    int argCheck = 0;
    while (index < argc)
    {
        if (strncmp(argv[index], "-H", 2) == 0)
        {
            usage(argv[0]);
            exit(0);
        }
        /***********************************************************************
        *  Processing working directory and input file                         *
        ***********************************************************************/
        else if (strncmp(argv[index], "-i", 2) == 0)
        {
            if (argv[index + 1] == NULL)
                return false;
            strcpy(inputFile, argv[index + 1]);
            argCheck++;
        }

        /***********************************************************************
        *  Processing working directory and output file                        *
        ***********************************************************************/
        else if (strncmp(argv[index], "-o", 2) == 0)
        {
            if (argv[index + 1] == NULL)
                return false;
            strcpy(outputFile, argv[index + 1]);
            argCheck++;
        }

        /***********************************************************************
        *  width of h264 video                                                 *
        ***********************************************************************/
        else if (strncmp(argv[index], "-w", 2) == 0)
        {
            if (argv[index + 1] == NULL)
                return false;
            *width = atoi(argv[index + 1]);
            argCheck++;
        }

        /***********************************************************************
        *  height of h264 video                                                *
        ***********************************************************************/
        else if (strncmp(argv[index], "-h", 6) == 0)
        {
            if (argv[index + 1] == NULL)
                return false;
            *height = atoi(argv[index + 1]);
            argCheck++;
        }
        index++;
    }

    if (argCheck != 4)
    {
        printf("Incorrect arguments:\n");
        usage(argv[0]);
        exit(0);
    }
    return true;
}

int main(int argc, char *argv[])
{
    bool error = true;
    char inputFilePath[400] ;
    char outputFilePath[400];
    unsigned int width=0, height=0;
    int numTargetBuffers = 16;
    /**************************************************************************
    * Parse arguments                                                         *
    **************************************************************************/
    error = parseArguments(argc, argv, inputFilePath, outputFilePath,
        &width, &height);
    if (error == false)
    {
        printf("Error during argument parsing\n");
        return -1;
    }
    /**************************************************************************
    * initialize the vulkan decode engine. This function creates vulkan       *
    * instance, device,queues and also required buffers for decoding          *
    **************************************************************************/
    VulkanDecodeEngine vulkanDecode;
    error = vulkanDecode.initDecodeEngine(width, height, numTargetBuffers);
    if (error == false)
    {
        printf("Failed during initializing vulkan device\n");
        return -1;
    }
    /**************************************************************************
    * Create amd i/o interface. This can be file based or even buffer based   *
    *  i/o                                                                    *
    **************************************************************************/
    amdInterface *input;
    input = new amdInterface();
    /**************************************************************************
    * Create and Initialize the H264 parser with input h264 file name         *
    **************************************************************************/
    std::string *fileName = new std::string(inputFilePath);
    h264Parse *pParser = new h264Parse((char *)fileName->c_str(), input);
    error = pParser->init();
    if (error == false)
    {
        printf("Error while initializing the parser\n");
        return -1;
    }
  
    FILE *foutput = fopen(outputFilePath, "wb");
    if (foutput == NULL)
    {
        printf("Error while openging the output file\n");
        return -1;
    }
    /**************************************************************************
    * Parse decode all the frames using vulkan decode APIs                    *
    **************************************************************************/
    error = parseAndDecodeFrame(pParser, &vulkanDecode,foutput);
    if (error == false)
    {
        printf("Error while decoding \n");
        return -1;
    }
    fclose(foutput);
    return 0;
}
/**
*******************************************************************************
*  @fn     parseAndDecodeFrame
*  @brief  This function parse the H264 video file and decodes using Vulkan APIs
*
*  @param[in] pParser              : Pointer to the parser class
*  @param[in] pVulkanDecode        : Pointer to the VulkanDecodeEngine class
*  @param[in/out] foutput          : file pointer for the output
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool parseAndDecodeFrame(h264Parse *pParser, VulkanDecodeEngine *pVulkanDecode,FILE *foutput)
{
    unsigned char frameEndDetected = 0;
    unsigned int frameSize = 0;
    int bufSize = 0,nalType;
    VkVideoDecodeH264PictureParametersBufferAMD picParamBuffAmd { 0 };
    unsigned int frameCount = 0;
    /**************************************************************************
    * Create buffers required for reading the NAL unit and also to store the  *
    * complete frame                                                          *
    **************************************************************************/
    unsigned char *readBuf = (unsigned char *)malloc(MAXH264FRAMESIZE);
    unsigned char *frameBuf = (unsigned char *)malloc(MAXH264FRAMESIZE);
    int targetBuffId = 0;
    bool error = false;
    
    while (1)
    {
        /**********************************************************************
        * Get one nal unit from the input h264 file                           *
        **********************************************************************/
        nalType = pParser->getNalUnit((readBuf), &bufSize);
        /**********************************************************************
        * If nal type is PPS/SPS parse & decode the same                      *
        **********************************************************************/
        if (nalType == SPS_NAL)
        {
            pParser->parseSps(readBuf, bufSize);
        }
        else if (nalType == PPS_NAL)
        {
            pParser->parsePps(readBuf, bufSize);
        }
        /*********************************************************************
        * If Naltype is I frame/slice or P frame/slice parse the required    *
        * slice header                                                       *
        * Presently supports only I & P slice, B frame is not supported      *
        *********************************************************************/
        else if ((nalType == I_FRAME_NAL) || (nalType == P_FRAME_NAL))
        {
            pParser->parseSliceHeader(&picParamBuffAmd, readBuf, bufSize, 
                                      frameBuf, &frameSize, &frameEndDetected);
            /*****************************************************************
            * In case of multi slice, detect the frame end and start the     *
            * vulkan decode process. Vulkan decode APIs takes one full frame,*
            * In case of multiple slices in a frame, all the slices including* 
            * slice header has to be packaged and sent for decode            *
            *****************************************************************/
            if (frameEndDetected)
            {
                /*************************************************************
                * Send one complete frme for decoding                        *
                *************************************************************/
                error = pVulkanDecode->beginDecodeFrame((frameBuf), frameSize, 
                                                        &picParamBuffAmd,
                                                        targetBuffId);
                CHECK_RESULT(error != true, "failed @ beginDecodeFrame()");
                /*************************************************************
                * submit the decode buffers for decoding                     *
                *************************************************************/
                error = pVulkanDecode->endDecodeFrame(targetBuffId);
                CHECK_RESULT(error != true, "failed @ endDecodeFrame()");
                /*************************************************************
                * Wait for decoding for the perticular target buffer         *
                * to be completed                                            *
                *************************************************************/
                error = pVulkanDecode->waitForDecodeToComplete(targetBuffId);
                CHECK_RESULT(error != true, "failed @ waitForDecodeToComplete()");
                /*************************************************************
                * Dump the output into a yuv nv12 file                       *
                *************************************************************/
                error = pVulkanDecode->dumpOutput(foutput, targetBuffId);
                CHECK_RESULT(error != true, "failed @ dumpOutput()");
                /*************************************************************
                * Once the decoding is over for the perticular frame, copy   *
                * the leftover bits to the frame buffer                      *
                *************************************************************/
                pParser->parseSliceHeader(&picParamBuffAmd, readBuf, bufSize, 
                                           frameBuf, &frameSize, 
                                           &frameEndDetected);
                CHECK_RESULT(error != true, "failed @ parseSliceHeader()");
                frameCount++;
                targetBuffId++;
                targetBuffId = targetBuffId & 0xf;
            }
        }
        /**********************************************************************
        * If naltype = -1, means end of stream is received, hence decode the  *
        * last frame                                                          *
        **********************************************************************/
        else if (nalType == -1)
        {
            error = pVulkanDecode->beginDecodeFrame((frameBuf), frameSize, 
                                                     &picParamBuffAmd, 
                                                     targetBuffId);
            CHECK_RESULT(error != true, "failed @ beginDecodeFrame()");
            error = pVulkanDecode->endDecodeFrame(targetBuffId);
            CHECK_RESULT(error != true, "failed @ endDecodeFrame()");

            error = pVulkanDecode->waitForDecodeToComplete(targetBuffId);
            CHECK_RESULT(error != true, "failed @ waitForDecodeToComplete()");
            error = pVulkanDecode->dumpOutput(foutput, targetBuffId);
            CHECK_RESULT(error != true, "failed @ dumpOutput()");
            frameCount++;
            break;
        }
       
    }
    printf("Frames Decoded %d \n", frameCount);
    /**************************************************************************
    * Once all the frmes are processed destroy the target buffers and vulkan  *
    * resources                                                               *
    **************************************************************************/
    pVulkanDecode->destroy(targetBuffId);
    free(readBuf);
    free(frameBuf);
    return true;
}
