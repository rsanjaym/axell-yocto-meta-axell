/*******************************************************************************
Copyright �2016 Advanced Micro Devices, Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1   Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.
2   Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.
*******************************************************************************/
/**
********************************************************************************
* @file <vulkanDeviceImpl.cpp>
*
* @brief This file contains functions related vulkan device APIs, 
* like device, queue creation 
*
********************************************************************************
*/
#include "vulkanDeviceImpl.h"

VulkanDeviceImpl::VulkanDeviceImpl()
{
    mUniQueueIndex = MAX_UNSIGNEDINT; 
    mDecodeQueueIndex = MAX_UNSIGNEDINT;
    mQueues.clear();
}
/**
*******************************************************************************
*  @fn     init
*  @brief  This function creates vulkan instance & device 
*
*  @param[in] width             : width of the video
*  @param[in] height            : Height of the video
*  @param[in] numTargetBuffers  : Number of target buffers used for decoding
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool VulkanDeviceImpl::init()
{
    bool res = createInstance(&mVulkanInstance);
    CHECK_RESULT(res != true, "failed to create instance");

    res = createVkDeviceAndQueues();
    CHECK_RESULT(res != true, "failed to create vulkan device and queues");
    return true;
}
/**
*******************************************************************************
*  @fn     createInstance
*  @brief  This function creates vulkan instance with required extensions
*
*  @param[in/out] vulkanInstance    : Pointer to the vulkan instance
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool VulkanDeviceImpl::createInstance(VkInstance *vulkanInstance)
{
    VkResult vkres = VK_SUCCESS;

    VkInstanceCreateInfo instanceCreateInfo = {};
    instanceCreateInfo.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    std::vector<const char*> instanceExtensions =
    {

        "VK_KHR_surface",
#if WIN32 
        "VK_KHR_win32_surface",
        "VK_AMD_yuv_image",
#endif
        "VK_AMD_video_decode_queue"
    };

    instanceCreateInfo.ppEnabledExtensionNames = instanceExtensions.data();
    instanceCreateInfo.enabledExtensionCount = static_cast<uint32_t> (instanceExtensions.size());

    std::vector<const char*> instanceLayers;

    instanceCreateInfo.ppEnabledLayerNames = instanceLayers.data();
    instanceCreateInfo.enabledLayerCount = static_cast<uint32_t> (instanceLayers.size());

    // VkApplicationInfo
    VkApplicationInfo applicationInfo = {};
    applicationInfo.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    applicationInfo.apiVersion = VK_API_VERSION_1_0;
    applicationInfo.applicationVersion = VK_MAKE_VERSION(1, 0, 0);
    applicationInfo.engineVersion = VK_MAKE_VERSION(1, 0, 0);
    applicationInfo.pApplicationName = "Vulkan application";
    applicationInfo.pEngineName = "Vulkan Simple decoder Engine";

    instanceCreateInfo.pApplicationInfo = &applicationInfo;

    vkres = vkCreateInstance(&instanceCreateInfo, nullptr, vulkanInstance);
    CHECK_RESULT(vkres != VK_SUCCESS, "failed to create instance with error code %d", vkres);

    return true;
}
/**
*******************************************************************************
*  @fn     createVkDeviceAndQueues
*  @brief  This function creates vulkan device & requried queues. 
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool VulkanDeviceImpl::createVkDeviceAndQueues()
{
    VkResult vkres = VK_SUCCESS;
    uint32_t physicalDeviceCount = 0;

    vkres = vkEnumeratePhysicalDevices(mVulkanInstance,
        &physicalDeviceCount,
        nullptr);
    CHECK_RESULT(vkres != VK_SUCCESS, "failed @ vkEnumeratePhysicalDevices() with error code %d", vkres);

    std::vector<VkPhysicalDevice> physicalDevices{ physicalDeviceCount };

    vkres = vkEnumeratePhysicalDevices(mVulkanInstance,
        &physicalDeviceCount,
        physicalDevices.data());
    CHECK_RESULT(vkres != VK_SUCCESS, "failed @ vkEnumeratePhysicalDevices() with error code %d", vkres);

    std::vector<VkDeviceQueueCreateInfo> deviceQueueCreateInfoItems;
    std::vector<float>                   queuePriorities;

    CHECK_RESULT(physicalDeviceCount != 1, "failed @ vkEnumeratePhysicalDevices() as multi GPU configuration is not suppported");

    uint32_t queueFamilyPropertyCount = 0;

    vkGetPhysicalDeviceQueueFamilyProperties(physicalDevices[0],
        &queueFamilyPropertyCount,
        nullptr);
    CHECK_RESULT(queueFamilyPropertyCount == 0, "failed @ vkGetPhysicalDeviceQueueFamilyProperties() as queueFamilyPropertyCount = 0");

    std::vector<VkQueueFamilyProperties> queueFamilyProperties{ queueFamilyPropertyCount };

    vkGetPhysicalDeviceQueueFamilyProperties(physicalDevices[0],
        &queueFamilyPropertyCount,
        queueFamilyProperties.data());

    int i = 0;
    /**************************************************************************
    * Enumarate all the Queues supported and select decode queue for decoding *
    **************************************************************************/
    for (const auto& queueFamilyProperty : queueFamilyProperties)
    {
        VkDeviceQueueCreateInfo queueCreateInfo = {};

        if (queuePriorities.size() < queueFamilyProperty.queueCount)
        {
            queuePriorities.resize(queueFamilyProperty.queueCount,
                1.0f);
        }

        queueCreateInfo.pQueuePriorities = &queuePriorities[0];
        queueCreateInfo.queueFamilyIndex = i;
        queueCreateInfo.queueCount = queueFamilyProperty.queueCount;
        queueCreateInfo.sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;

        if ((queueFamilyProperty.queueFlags & VK_QUEUE_COMPUTE_BIT) &&
            (queueFamilyProperty.queueFlags & VK_QUEUE_GRAPHICS_BIT) &&
            mUniQueueIndex == MAX_UNSIGNEDINT)
        {
            mUniQueueIndex = i;
            deviceQueueCreateInfoItems.push_back(queueCreateInfo);
        }
        else
            if (queueFamilyProperty.queueFlags & VK_QUEUE_VIDEO_DECODE_BIT_AMD &&
                mDecodeQueueIndex == MAX_UNSIGNEDINT)
            {
                if (queueFamilyProperty.queueCount > 1)
                {
                    queueCreateInfo.queueCount = 1;
                }

                mDecodeQueueIndex = i;
                deviceQueueCreateInfoItems.push_back(queueCreateInfo);
            }
        ++i;
    }

    VkDeviceCreateInfo deviceCreateInfo = {};

    deviceCreateInfo.sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;
    deviceCreateInfo.queueCreateInfoCount = static_cast<uint32_t>(deviceQueueCreateInfoItems.size());
    deviceCreateInfo.pQueueCreateInfos = &deviceQueueCreateInfoItems[0];

    std::vector<const char*> deviceLayers;

    deviceCreateInfo.ppEnabledLayerNames = deviceLayers.data();
    deviceCreateInfo.enabledLayerCount = static_cast<uint32_t> (deviceLayers.size());

    std::vector<const char*> deviceExtensions =
    {
        "VK_KHR_swapchain"
    };

    deviceCreateInfo.ppEnabledExtensionNames = deviceExtensions.data();
    deviceCreateInfo.enabledExtensionCount = static_cast<uint32_t> (deviceExtensions.size());

    VkDevice device = nullptr;
    /**************************************************************************
    * Create device with the selected Queues only                             *
    **************************************************************************/
    vkres = vkCreateDevice(physicalDevices[0],
        &deviceCreateInfo,
        nullptr,
        &device);
    CHECK_RESULT(vkres != VK_SUCCESS, "failed @ vkCreateDevice() with error code %d", vkres);
    CHECK_RESULT(device == nullptr, "failed @ vkCreateDevice() as device is NULL");
    for (auto queueCreateInfo : deviceQueueCreateInfoItems)
    {
        for (uint32_t nQueue = 0; nQueue < queueCreateInfo.queueCount; ++nQueue)
        {
            VkQueue queue = VK_NULL_HANDLE;
            vkGetDeviceQueue(device,
                queueCreateInfo.queueFamilyIndex,
                nQueue,
                &queue);
            CHECK_RESULT(queue == VK_NULL_HANDLE, "failed @ vkGetDeviceQueue() as device queue is nullptr");

            mQueues[queueCreateInfo.queueFamilyIndex].push_back(queue);
        }
    }

    mVulkanDevice = device;
    mVulkanPhisicalDevice = physicalDevices[0];

    CHECK_RESULT(mDecodeQueueIndex == MAX_UNSIGNEDINT, "Decode queue index is not found");
    
    return true;
}
/**
*******************************************************************************
*  @fn     createCommandPool
*  @brief  This function creates vulkan command pool for the queue family. 
*           eg decode queue
*
*  @param[in] familyIndex             : Vulkan Queue family index
*  @param[in/out] commandPool         : pointer to the command pool created
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool VulkanDeviceImpl::createCommandPool(int familyIndex, VkCommandPool *commandPool)
{
    VkCommandPoolCreateInfo commandPoolCreateInfo = {};
    VkResult                vkres;

    commandPoolCreateInfo.queueFamilyIndex = familyIndex;
    commandPoolCreateInfo.sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;

    vkres = vkCreateCommandPool(mVulkanDevice, &commandPoolCreateInfo, nullptr, commandPool);
    CHECK_RESULT(vkres != VK_SUCCESS, "failed @ vkCreateCommandPool() with error code %d", vkres);
    return true;

}
/**
*******************************************************************************
*  @fn     createPipelineCache
*  @brief  This function creates vulkan pipleline cache
*
*  @param[in] pipelineCache             : Pointer to the pipeline cache
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool VulkanDeviceImpl::createPipelineCache(VkPipelineCache* pipelineCache)
{
    VkPipelineCacheCreateInfo pipelineCacheCreateInfo = {};
    VkResult                  vkres;

    pipelineCacheCreateInfo.initialDataSize = 0;
    pipelineCacheCreateInfo.pInitialData = nullptr;
    pipelineCacheCreateInfo.sType = VK_STRUCTURE_TYPE_PIPELINE_CACHE_CREATE_INFO;

    vkres = vkCreatePipelineCache(mVulkanDevice, &pipelineCacheCreateInfo, nullptr, pipelineCache);
    CHECK_RESULT(vkres != VK_SUCCESS, "failed @ vkCreatePipelineCache() with error code %d", vkres);
    return true;
}
/**
*******************************************************************************
*  @fn     createCommandBuffer
*  @brief  This function creates Command buffer
*
*  @param[in] commandPool       : Pointer to the command pool
*  @param[in/out] pCmdBuffer    : Pointer to the command buffer 
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool VulkanDeviceImpl::createCommandBuffer(VkCommandPool commandPool, VkCommandBuffer* pCmdBuffer)
{
    VkCommandBufferAllocateInfo cmdBufferAllocInfo = {};
    VkResult vkres = VK_SUCCESS;

    cmdBufferAllocInfo.commandBufferCount = 1;
    cmdBufferAllocInfo.commandPool = commandPool;
    cmdBufferAllocInfo.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    cmdBufferAllocInfo.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;

    vkres = vkAllocateCommandBuffers(mVulkanDevice,
        &cmdBufferAllocInfo,
        pCmdBuffer);
    CHECK_RESULT(vkres != VK_SUCCESS, "failed @ vkAllocateCommandBuffers() with error code %d", vkres);
    return true;
}
/**
*******************************************************************************
*  @fn     createVulkanSurface
*  @brief  This function creates vulkan instance & device
*
*  @param[in/out] vulkanSufPtr  : Pointer to the vulkan surface
*  @param[in] format            : Format of the image to be created  
*  @param[in] numPlanes         : Number of planes required
*  @param[in] width             : width of the video
*  @param[in] height            : Height of the video
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool VulkanDeviceImpl::createVulkanSurface(vulkanSurface *vulkanSufPtr, 
                                           VkFormat format, int numPlanes, 
                                           int width, int height)
{
    VkResult vkres = VK_SUCCESS;
    VkImageCreateInfo imageCreateInfo = {};

    CHECK_RESULT(format != VK_FORMAT_NV12_AMD, "Un-supported surface format @ createVulkanSurface()");

    const uint32_t queueFamilyIndices[] =
    {
        mUniQueueIndex,
        mDecodeQueueIndex
    };
    const uint32_t nQueueFamilyIndices = sizeof(queueFamilyIndices) / sizeof(queueFamilyIndices[0]);

    imageCreateInfo.initialLayout = VK_IMAGE_LAYOUT_PREINITIALIZED;
    imageCreateInfo.usage = VK_IMAGE_USAGE_TRANSFER_SRC_BIT;
    imageCreateInfo.arrayLayers = 1;
    imageCreateInfo.extent.depth = 1;
    imageCreateInfo.extent.height = height;
    imageCreateInfo.extent.width = width;
    imageCreateInfo.flags = 0;
    imageCreateInfo.format = format;
    imageCreateInfo.imageType = VK_IMAGE_TYPE_2D;
    imageCreateInfo.mipLevels = 1;
    imageCreateInfo.pQueueFamilyIndices = queueFamilyIndices;
    imageCreateInfo.queueFamilyIndexCount = nQueueFamilyIndices;
    imageCreateInfo.samples = VK_SAMPLE_COUNT_1_BIT;
    imageCreateInfo.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    imageCreateInfo.sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO;
    imageCreateInfo.tiling = VK_IMAGE_TILING_LINEAR;

    
    vkres = vkCreateImage(mVulkanDevice, &imageCreateInfo, nullptr /* pAllocator */, &vulkanSufPtr->hImage);
    CHECK_RESULT(format != VK_FORMAT_NV12_AMD, "Un-supported surface format @ createVulkanSurface()");
    CHECK_RESULT(numPlanes != 2, "Un-supported number of planes @ createVulkanSurface()");

    CHECK_RESULT((vkres != VK_SUCCESS || vulkanSufPtr->hImage == VK_NULL_HANDLE), "error during vkCreateImage() error code = %d",vkres);

    VkMemoryRequirements memoryRequirements = {};
    vkGetImageMemoryRequirements(mVulkanDevice, vulkanSufPtr->hImage, &memoryRequirements);

    int memsize = 0;
    for (int i = 0; i < numPlanes; ++i)
    {
        VkImageSubresource imageSubresource = {};
        VkSubresourceLayout subresourceLayout = {};
        imageSubresource.aspectMask = (i == 0) ? VK_IMAGE_ASPECT_Y_BIT_AMD : VK_IMAGE_ASPECT_CBCR_AMD; 

        vkGetImageSubresourceLayout(mVulkanDevice, vulkanSufPtr->hImage, &imageSubresource, &subresourceLayout);

        memsize += ((int)subresourceLayout.size); 
    }
    if (memsize > memoryRequirements.size)
    {
        memoryRequirements.size = memsize;
    }
    vulkanSufPtr->hSize = memoryRequirements.size;

    bool err = allocateVulkanMemory(
        memoryRequirements,
        true,   /* needsMappableMemory */
        false,  /* needsCoherentMemory */
        &vulkanSufPtr->hMemory);
    CHECK_RESULT((err == false), "Failed @allocateVulkanMemory");

    vkres = vkBindImageMemory(mVulkanDevice, vulkanSufPtr->hImage, vulkanSufPtr->hMemory, 0 /* memoryOffset */);
    CHECK_RESULT((vkres != VK_SUCCESS), "Failed @vkBindImageMemory with error code %d", vkres);
    return true;
}
/**
*******************************************************************************
*  @fn     allocateVulkanMemory
*  @brief  This function allocates memory
*
*  @param[in] memoryRequirements   : pointer to the memory requirement
*  @param[in] needsMappableMemory  : flag to indicate whether you need mappable 
*                                emory or only GPU needs to be using the memory
*  @param[in] needsCoherentMemory  : needs to be coherent or not
*  @param[out] hMemory             : pointer to the allocated memory
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/

bool VulkanDeviceImpl::allocateVulkanMemory(
    const VkMemoryRequirements& memoryRequirements,
    bool                        needsMappableMemory,
    bool                        needsCoherentMemory,
    VkDeviceMemory*             hMemory
    )
{
    VkPhysicalDeviceMemoryProperties memoryProps;
    VkResult                         vkres;

    CHECK_RESULT((mVulkanDevice == NULL) , "vk device not initialized");
    if (!needsMappableMemory)
    {
        CHECK_RESULT((needsCoherentMemory == true), "Unsupported memory requested");
    }

    vkGetPhysicalDeviceMemoryProperties(mVulkanPhisicalDevice, &memoryProps);
    /**************************************************************************
    * Determine index of the memory type to allocate from                     *
    **************************************************************************/
    uint32_t memoryTypeIndex = MAX_UNSIGNEDINT;

    for (uint32_t nMemoryType = 0; nMemoryType < memoryProps.memoryTypeCount; ++nMemoryType)
    {
        if ((needsCoherentMemory && memoryProps.memoryTypes[nMemoryType].propertyFlags & VK_MEMORY_PROPERTY_HOST_COHERENT_BIT || !needsCoherentMemory) &&
            needsMappableMemory && memoryProps.memoryTypes[nMemoryType].propertyFlags & VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT || !needsMappableMemory)
        {
            if ((memoryRequirements.memoryTypeBits & (1 << nMemoryType)) != 0)
            {
                memoryTypeIndex = nMemoryType;
                break;
            }
        }
    }
    CHECK_RESULT((memoryTypeIndex == MAX_UNSIGNEDINT), "Unsupported memory requested");

    // Allocate
    VkMemoryAllocateInfo alloc_info = {};
    alloc_info.allocationSize = memoryRequirements.size;
    alloc_info.memoryTypeIndex = memoryTypeIndex;
    alloc_info.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;

    vkres = vkAllocateMemory(mVulkanDevice, &alloc_info, nullptr, hMemory);
    CHECK_RESULT((vkres != VK_SUCCESS), "Failed @vkAllocateMemory with error code %d", vkres);
    CHECK_RESULT((hMemory == VK_NULL_HANDLE), "Failed @vkAllocateMemory, cannot allocate memory");

    return true;
}
/**
*******************************************************************************
*  @fn     createBuffer
*  @brief  This function creates the vulkan buffer
*
*  @param[in] size             : size of the buffer to be allocated
*  @param[in/out] pBuffer          : pointer to hold the vulkan buffer
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool VulkanDeviceImpl::createBuffer(unsigned int size, vulkanBuffer* pBuffer)
{
    CHECK_RESULT((mVulkanDevice == NULL) , "vk device not initialized");

    VkBufferCreateInfo createInfo = {};
    VkResult           vkres = VK_SUCCESS;
    bool err = false;

    const uint32_t queueFamilyIndices[] =
    {
        mUniQueueIndex,
        mDecodeQueueIndex
    };
    const uint32_t nQueueFamilyIndices = sizeof(queueFamilyIndices) / sizeof(queueFamilyIndices[0]);

    createInfo.pQueueFamilyIndices = queueFamilyIndices;
    createInfo.queueFamilyIndexCount = nQueueFamilyIndices;
    createInfo.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    createInfo.size = size;
    createInfo.sType = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO;
    createInfo.usage = VK_BUFFER_USAGE_TRANSFER_SRC_BIT;

    vkres = vkCreateBuffer(mVulkanDevice, &createInfo, nullptr, &pBuffer->mBuffer);
    CHECK_RESULT((vkres != VK_SUCCESS), "Failed @vkCreateBuffer with error code %d", vkres);

    /**************************************************************************
    * Allocate memory for the object                                          *
    **************************************************************************/
    VkMemoryRequirements memoryRequirements;

    vkGetBufferMemoryRequirements(mVulkanDevice, pBuffer->mBuffer, &memoryRequirements);
    err = allocateVulkanMemory(memoryRequirements,
        true,  /* needsMappableMemory */
        true,  /* needsCoherentMemory */
        &pBuffer->mMemory);
    CHECK_RESULT((err != true), "Failed @allocateVulkanMemory");

    vkres = vkBindBufferMemory(mVulkanDevice, pBuffer->mBuffer, pBuffer->mMemory, 0); /* memoryOffset */
    CHECK_RESULT((vkres != VK_SUCCESS), "Failed @vkBindBufferMemory with error code %d", vkres);

    pBuffer->mSize = size;

    return true;
}
/**
*******************************************************************************
*  @fn     releaseResource
*  @brief  This function releases the vulkan device, queue and instance
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool VulkanDeviceImpl::releaseResource()
{
    CHECK_RESULT((mVulkanDevice == VK_NULL_HANDLE), "Device not initialized ");

    vkDestroyDevice(mVulkanDevice, nullptr);
    mVulkanPhisicalDevice = VK_NULL_HANDLE;
    mVulkanDevice = VK_NULL_HANDLE;

    mUniQueueIndex = MAX_UNSIGNEDINT;
    mDecodeQueueIndex = MAX_UNSIGNEDINT;

    if (mVulkanInstance != VK_NULL_HANDLE)
    {
        vkDestroyInstance(mVulkanInstance, nullptr);
        mVulkanInstance = VK_NULL_HANDLE;
    }
    mQueues.clear();
    return true;
}
/**
*******************************************************************************
*  @fn     releaseSurface
*  @brief  This function releases the memory associated with the surface
*
*  @param[in] pSurface             : Pointer to the vulkan image to be released
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool VulkanDeviceImpl::releaseSurface(vulkanSurface *pSurface)
{
    CHECK_RESULT((mVulkanDevice == VK_NULL_HANDLE), "Device not initialized ");
    CHECK_RESULT((pSurface == NULL), "Surface is not initialized");

    if (pSurface->hImage)
    {
        vkDestroyImage(mVulkanDevice, pSurface->hImage, nullptr);
        pSurface->hImage = nullptr;
    }
    if (pSurface->hMemory)
    {
        vkFreeMemory(mVulkanDevice, pSurface->hMemory, nullptr);
        pSurface->hMemory = nullptr;
    }
    return true;
}
/**
*******************************************************************************
*  @fn     releaseBuffer
*  @brief  This function releses vulkan buffer
*
*  @param[in] pBuffer             : Pointer to the vulkan buffer to be released
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool VulkanDeviceImpl::releaseBuffer(vulkanBuffer* pBuffer)
{
    CHECK_RESULT((mVulkanDevice == VK_NULL_HANDLE), "Device not initialized ");
    CHECK_RESULT((pBuffer == NULL), "Surface is not initialized");

    if (pBuffer->mBuffer)
    {
        vkDestroyBuffer(mVulkanDevice, pBuffer->mBuffer, nullptr);
        pBuffer->mBuffer = nullptr;
    }
    if (pBuffer->mMemory)
    {
        vkFreeMemory(mVulkanDevice, pBuffer->mMemory, nullptr);
        pBuffer->mMemory = nullptr;
    }
    return true;
}