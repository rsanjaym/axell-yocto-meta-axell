/*
 ***********************************************************************************************************************
 *
 *  Trade secret of Advanced Micro Devices, Inc.
 *  Copyright (c) 2014-2016, Advanced Micro Devices, Inc., (unpublished)
 *
 *  All rights reserved. This notice is intended as a precaution against inadvertent publication and does not imply
 *  publication or any waiver of confidentiality. The year included in the foregoing notice is the year of creation of
 *  the work.
 *
 **********************************************************************************************************************/
/**
 **********************************************************************************************************************
 * @file  vk_amd_yuv_image.h
 * @brief Temporary internal header for YUV image format extension. Should be removed once the extension is published
 *        and the API gets included in the official Vulkan header.
 **********************************************************************************************************************
 */
#ifndef VK_AMD_YUV_IMAGE_H_
#define VK_AMD_YUV_IMAGE_H_

#include "vk_internal_ext_helper.h"

#define VK_AMD_YUV_IMAGE_SPEC_VERSION                       1
#define VK_AMD_YUV_IMAGE_EXTENSION_NAME                     "VK_AMD_yuv_image"

#define VK_AMD_YUV_IMAGE_EXTENSION_NUMBER                   17

#define VK_AMD_YUV_IMAGE_ENUM(type, offset) \
    VK_EXTENSION_ENUM(VK_AMD_YUV_IMAGE_EXTENSION_NUMBER, type, offset)

#define VK_FORMAT_AYUV_AMD                                      VK_AMD_YUV_IMAGE_ENUM(VkFormat, 0)
#define VK_FORMAT_UYVY_AMD                                      VK_AMD_YUV_IMAGE_ENUM(VkFormat, 1)
#define VK_FORMAT_VYUY_AMD                                      VK_AMD_YUV_IMAGE_ENUM(VkFormat, 2)
#define VK_FORMAT_YUY2_AMD                                      VK_AMD_YUV_IMAGE_ENUM(VkFormat, 3)
#define VK_FORMAT_YVY2_AMD                                      VK_AMD_YUV_IMAGE_ENUM(VkFormat, 4)
#define VK_FORMAT_YV12_AMD                                      VK_AMD_YUV_IMAGE_ENUM(VkFormat, 5)
#define VK_FORMAT_NV11_AMD                                      VK_AMD_YUV_IMAGE_ENUM(VkFormat, 6)
#define VK_FORMAT_NV12_AMD                                      VK_AMD_YUV_IMAGE_ENUM(VkFormat, 7)
#define VK_FORMAT_NV21_AMD                                      VK_AMD_YUV_IMAGE_ENUM(VkFormat, 8)
#define VK_FORMAT_P016_AMD                                      VK_AMD_YUV_IMAGE_ENUM(VkFormat, 9)
#define VK_FORMAT_P010_AMD                                      VK_AMD_YUV_IMAGE_ENUM(VkFormat, 10)

#define VK_IMAGE_ASPECT_Y_BIT_AMD                               VK_EXTENSION_BIT(VkImageAspectFlagBits, 4)
#define VK_IMAGE_ASPECT_CB_BIT_AMD                              VK_EXTENSION_BIT(VkImageAspectFlagBits, 5)
#define VK_IMAGE_ASPECT_CR_BIT_AMD                              VK_EXTENSION_BIT(VkImageAspectFlagBits, 6)
#define VK_IMAGE_ASPECT_CBCR_AMD                                (VK_IMAGE_ASPECT_CB_BIT_AMD | VK_IMAGE_ASPECT_CR_BIT_AMD)
#define VK_IMAGE_ASPECT_YCBCR_AMD                               (VK_IMAGE_ASPECT_Y_BIT_AMD | VK_IMAGE_ASPECT_CBCR_AMD)

typedef struct VkColorSpaceConversionMatrixAMD
{
    float                               matrix[3][4];       // Values forming the color-space conversion matrix.
                                                            // For RGB to YUV blits the values are used as follows:
                                                            //  Y = dot( [R G B 1], [row #0] )
                                                            //  U = dot( [R G B 1], [row #1] )
                                                            //  V = dot( [R G B 1], [row #2] )
                                                            // For YUV to RGB blits the values are used as follows:
                                                            //  R = dot( [Y U V 1], [row #0] )
                                                            //  G = dot( [Y U V 1], [row #1] )
                                                            //  B = dot( [Y U V 1], [row #2] )
                                                            // Alpha is always copied directly.
} VkColorSpaceConversionMatrixAMD;

typedef void (VKAPI_PTR *PFN_vkCmdColorSpaceBlitImageAMD)(
    VkCommandBuffer                         commandBuffer,
    VkImage                                 srcImage,
    VkImageLayout                           srcImageLayout,
    VkImage                                 dstImage,
    VkImageLayout                           dstImageLayout,
    uint32_t                                regionCount,
    const VkImageBlit*                      pRegions,
    VkFilter                                filter,
    const VkColorSpaceConversionMatrixAMD*  pMatrix);

VKAPI_ATTR void VKAPI_CALL vkCmdColorSpaceBlitImageAMD(
    VkCommandBuffer                         commandBuffer,
    VkImage                                 srcImage,
    VkImageLayout                           srcImageLayout,
    VkImage                                 dstImage,
    VkImageLayout                           dstImageLayout,
    uint32_t                                regionCount,
    const VkImageBlit*                      pRegions,
    VkFilter                                filter,
    const VkColorSpaceConversionMatrixAMD*  pMatrix);

#endif /* VK_AMD_YUV_IMAGE_H_ */
