/*
 ***********************************************************************************************************************
 *
 *  Trade secret of Advanced Micro Devices, Inc.
 *  Copyright (c) 2014-2016, Advanced Micro Devices, Inc., (unpublished)
 *
 *  All rights reserved. This notice is intended as a precaution against inadvertent publication and does not imply
 *  publication or any waiver of confidentiality. The year included in the foregoing notice is the year of creation of
 *  the work.
 *
 **********************************************************************************************************************/
/**
 **********************************************************************************************************************
 * @file  vk_amd_shader_extensions.h
 * @brief Temporary internal header for shader extensions. Entries should be removed once the corresponding extensions
 * are published and the extension #defines gets included in the official Vulkan header.
 **********************************************************************************************************************
 */
#ifndef VK_AMD_SHADER_EXTENSIONS_H_
#define VK_AMD_SHADER_EXTENSIONS_H_

/* VK_AMD_shader_ballot */
#define VK_AMD_SHADER_BALLOT_SPEC_VERSION                           1
#define VK_AMD_SHADER_BALLOT_EXTENSION_NAME                         "VK_AMD_shader_ballot"
#define VK_AMD_SHADER_BALLOT_EXTENSION_NUMBER                       20

#endif /* VK_AMD_SHADER_EXTENSIONS_H_ */
