/*******************************************************************************
Copyright ©2016 Advanced Micro Devices, Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1   Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.
2   Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.
*******************************************************************************/
/**
 ******************************************************************************
 * @file <TileParser.cpp>
 *
 * @brief Source file implements parsing individual h264 files
 *
 ******************************************************************************
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Typedef.h"
#include "TileParser.h"
#include "IOInterface.h"


#define SPSBUFLEN   32

#define SMALLBUFSIZE    (1 * 1024)

const int quantMatrix[16] = { //to be use if no q matrix is chosen
    16, 16, 16, 16,
    16, 16, 16, 16,
    16, 16, 16, 16,
    16, 16, 16, 16
};
const int quantMatrix_8[64] = { //to be use if no q matrix is chosen
    16, 16, 16, 16, 16, 16, 16, 16,
    16, 16, 16, 16, 16, 16, 16, 16,
    16, 16, 16, 16, 16, 16, 16, 16,
    16, 16, 16, 16, 16, 16, 16, 16,
    16, 16, 16, 16, 16, 16, 16, 16,
    16, 16, 16, 16, 16, 16, 16, 16,
    16, 16, 16, 16, 16, 16, 16, 16,
    16, 16, 16, 16, 16, 16, 16, 16
};
/**
*******************************************************************************
*  @fn     init
*  @brief  This function Initializes the H264 parser
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool h264Parse::init()
{
    if ((WelsCreateDecoder(&mPDecoder)) || (mPDecoder == NULL))
    {
        printf("Failed to create decoder \n");
        return false;
    }

    sDecParam.sVideoProperty.size = sizeof(sDecParam.sVideoProperty);
    sDecParam.eOutputColorFormat = videoFormatI420;
    sDecParam.sVideoProperty.eVideoBsType = VIDEO_BITSTREAM_DEFAULT;
    sDecParam.bParseOnly = true;

    if (mPDecoder->Initialize(&sDecParam))
    {
        printf("Decoder initialize failed \n");
        return false;
    }
    return true;
}
/**
*******************************************************************************
*  @fn     parseSps
*  @brief  This function parses the SPS header
*
*  @param[in] nalBuf         : Pointer to the input nal buffer
*  @param[in] bufSize        : Size of the Nal buffer
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool h264Parse::parseSps(unsigned char *nalBuf,unsigned int bufSize)
{
    SParserBsInfo sparserInfo;
    mPDecoder->DecodeParser((nalBuf), bufSize, &sparserInfo);
    mPDecoder->DecodeParser(NULL, 0, &sparserInfo);
    if(!firstTimeFlag)
        mNewSps = 1;
    return true;
}
/**
*******************************************************************************
*  @fn     parsePps
*  @brief  This function parses the SPS header
*
*  @param[in] nalBuf         : Pointer to the input nal buffer
*  @param[in] bufSize        : Size of the Nal buffer
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool h264Parse::parsePps(unsigned char *nalBuf, unsigned int bufSize)
{
    SParserBsInfo sparserInfo;
    mPDecoder->DecodeParser((nalBuf), bufSize, &sparserInfo);
    mPDecoder->DecodeParser(NULL, 0, &sparserInfo);
    if (!firstTimeFlag)
        mNewPps = 1;
    return true;
}
/**
*******************************************************************************
*  @fn     fillSpsPpsInfo
*  @brief  This function fills the parsed SPS and PPS information into AMD 
*          specific structure.
*
*  @param[in] picParamBuffAmd : Pointer to the AMD specific videoDecode 
*                               information buffer
*  @param[in] spsId           : SPS ID
*  @param[in] ppsId           : PPS ID
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool h264Parse::fillSpsPpsInfo(VkVideoDecodeH264PictureParametersBufferAMD *picParamBuffAmd,
                               unsigned int spsId, unsigned int ppsId)
{
    int bFieldPicFlag = 0;
    WelsDec::CWelsDecoder *wels = (WelsDec::CWelsDecoder *)(mPDecoder);
    WelsDec::PWelsDecoderContext ctx = wels->m_pDecContext;

    WelsDec::SSps sps = ctx->sSpsBuffer[spsId];

    picParamBuffAmd->profile = h264GetProfile(sps.uiProfileIdc);
    picParamBuffAmd->level = sps.uiLevelIdc;
    picParamBuffAmd->chromaFormat = sps.uiChromaFormatIdc;
    picParamBuffAmd->bitDepthChromaMinus8 = sps.uiBitDepthChroma;
    picParamBuffAmd->bitDepthLumaMinus8 = sps.uiBitDepthLuma;
    picParamBuffAmd->log2MaxFrameNumMinus4 = sps.uiLog2MaxFrameNum - 4;
    picParamBuffAmd->log2MaxPicOrderCntLsbMinus4 = sps.iLog2MaxPocLsb;
    picParamBuffAmd->numRefFrames = sps.iNumRefFrames;
    picParamBuffAmd->picOrderCntType = sps.uiPocType;

    picParamBuffAmd->spsInfoFlags =
        ((sps.bSeparateColorPlaneFlag ? 1 : 0) << SPS_INFO_H264_RESIDUAL_COLOUR_TRANSFORM_FLAG_SHIFT)
        + ((sps.bDeltaPicOrderAlwaysZeroFlag ? 1 : 0) << SPS_INFO_H264_DELTA_PIC_ORDER_ALWAYS_ZERO_FLAG_SHIFT)
        + ((sps.bFrameMbsOnlyFlag ? 1 : 0) << SPS_INFO_H264_FRAME_MBS_ONLY_FLAG_SHIFT)
        + (((sps.bMbaffFlag && (bFieldPicFlag == 0)) ? 1 : 0) << SPS_INFO_H264_MB_ADAPTIVE_FRAME_FIELD_FLAG_SHIFT)
        + ((sps.bDirect8x8InferenceFlag ? 1 : 0) << SPS_INFO_H264_DIRECT_8X8_INFERENCE_FLAG_SHIFT)
        + (1 << SPS_INFO_H264_EXTENSION_SUPPORT_FLAG_MASK);

    CHECK_RESULT((sps.bSeqScalingMatrixPresentFlag == true), "Scaling list is not supported");


    for (int i = 0; i<6; i++)
    {
        for (int j = 0; j<16; j++)
        {
            picParamBuffAmd->scalingList4x4[i][j] = quantMatrix[j];
        }
    }
    for (int i = 0; i<2; i++)
    {
        for (int j = 0; j<64; j++)
        {
            picParamBuffAmd->scalingList8x8[i][j] = quantMatrix_8[j];
        }
    }

    for (int i = 0; i<16; i++)
    {
        picParamBuffAmd->refFrameList[i] = 0xFF;
        picParamBuffAmd->frameNumList[i] = 0x0;
        picParamBuffAmd->fieldOrderCntList[i][0] = 0;
        picParamBuffAmd->fieldOrderCntList[i][1] = 0;
    }
    /**************************************************************************
    * decode surface index provided by player                                 *
    **************************************************************************/
    picParamBuffAmd->decodedPicIdx = 0;

    /**************************************************************************
    * number of reference frame of the current picture.                       *
    **************************************************************************/
    picParamBuffAmd->currPicRefFrameNum = sps.iNumRefFrames;


    WelsDec::SPps pps = ctx->sPpsBuffer[ppsId];
    picParamBuffAmd->picInitQpMinus26 = pps.iPicInitQp - 26;
    picParamBuffAmd->picInitQsMinus26 = pps.iPicInitQs - 26;
    picParamBuffAmd->chromaQpIndexOffset = pps.iChromaQpIndexOffset[0];
    picParamBuffAmd->secondChromaQpIndexOffset = pps.iChromaQpIndexOffset[1];
    picParamBuffAmd->numSliceGroupsMinus1 = pps.uiNumSliceGroups - 1;
    picParamBuffAmd->sliceGroupMapType = pps.uiSliceGroupMapType;
    picParamBuffAmd->numRefIdxl0ActiveMinus1 = pps.uiNumRefIdxL0Active - 1;
    picParamBuffAmd->numRefIdxl1ActiveMinus1 = pps.uiNumRefIdxL1Active - 1;
    picParamBuffAmd->sliceGroupChangeRateMinus1 = pps.uiSliceGroupChangeRate;

    picParamBuffAmd->ppsInfoFlags =
        ((pps.bEntropyCodingModeFlag ? 1 : 0) << PPS_INFO_H264_ENTROPY_CODING_MODE_FLAG_SHIFT)
        + ((pps.bPicOrderPresentFlag ? 1 : 0) << PPS_INFO_H264_PIC_ORDER_PRESENT_FLAG_SHIFT)
        + ((pps.bWeightedPredFlag ? 1 : 0) << PPS_INFO_H264_WEIGHTED_PRED_FLAG_SHIFT)
        + ((pps.uiWeightedBipredIdc ? 1 : 0) << PPS_INFO_H264_WEIGHTED_BIPRED_IDC_SHIFT)
        + ((pps.bDeblockingFilterControlPresentFlag ? 1 : 0) << PPS_INFO_H264_DEBLOCKING_FILTER_CONTROL_PRESENT_FLAG_SHIFT)
        + ((pps.bConstainedIntraPredFlag ? 1 : 0) << PPS_INFO_H264_CONSTRAINED_INTRA_PRED_FLAG_SHIFT)
        + ((pps.bRedundantPicCntPresentFlag ? 1 : 0) << PPS_INFO_H264_REDUNDANT_PIC_CNT_PRESENT_FLAG_SHIFT)
        + ((pps.bTransform8x8ModeFlag ? 1 : 0) << PPS_INFO_H264_TRANSFORM_8X8_MODE_FLAG_SHIFT);

    CHECK_RESULT((pps.bPicScalingMatrixPresentFlag == true), "Scaling list is not supported");
    return true;

}
/**
*******************************************************************************
*  @fn     parseSliceHeader
*  @brief  This function parses the slice header and fills the required 
*          information in AMD specific video info buffer. 
*          This also detects the frame end and informs the application
*
*  @param[in] picParamBuffAmd   : Pointer to the AMD specific videoDecode
*                               information buffer
*  @param[in] nalBuf            : Pointer to the NAL buffer
*  @param[in] bufSize           : Size of the NAL
*  @param[in/out] frameBuf      : pointer to the complete frame(includes multiple slices)
*  @param[out] frameSize        : Size of the frame 
*  @param[out] frameEndDetected : will be set to 1 if frame end is detected
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
bool h264Parse::parseSliceHeader(VkVideoDecodeH264PictureParametersBufferAMD *picParamBuffAmd, 
                unsigned char *nalBuf, unsigned int bufSize,unsigned char *frameBuf,unsigned int *frameSize,
                unsigned char *frameEndDetected
                )
{
    SParserBsInfo sparserInfo;
    mPDecoder->DecodeParser((nalBuf), bufSize, &sparserInfo);
    mPDecoder->DecodeParser(NULL, 0, &sparserInfo);
    int topPoc = 0, bottomPoc = 0;

    WelsDec::CWelsDecoder *wels = (WelsDec::CWelsDecoder *)(mPDecoder);
    WelsDec::PWelsDecoderContext ctx = wels->m_pDecContext;

    WelsDec::SSliceHeader sliceHeader = *ctx->pSliceHeader;

    if (*frameEndDetected == 0)
    {
        mFrameNum = sliceHeader.iFrameNum;
        
        if ((firstTimeFlag) || (mPpsId != sliceHeader.iPpsId) || (mSpsId != sliceHeader.iSpsId) || (mNewSps == 1) || (mNewPps ==1))
        {
            fillSpsPpsInfo(picParamBuffAmd, sliceHeader.iSpsId, sliceHeader.iPpsId);
            decodePoc(sliceHeader.iPpsId, sliceHeader.iSpsId, &topPoc, &bottomPoc);
            picParamBuffAmd->currFieldOrderCntList[0] = topPoc;
            picParamBuffAmd->currFieldOrderCntList[1] = bottomPoc;
            mPrevFrameNum = mFrameNum;
            firstTimeFlag = 0;
        }
        mPpsId = sliceHeader.iPpsId;
        mSpsId = sliceHeader.iSpsId;

        if ( (mPrevFrameNum != mFrameNum) 
            || ((mPpsId != sliceHeader.iPpsId) || (mSpsId != sliceHeader.iSpsId) || (mNewSps == 1) || (mNewPps == 1)))
        {

            *frameEndDetected = 1;
            *frameSize = mFrameBufOffset;
            mFrameBufOffset = 0;
            mPrevFrameNum = mFrameNum;
            mNewSps = 0; mNewPps = 0;
            return true;
        }
        picParamBuffAmd->frameNum = mFrameNum;
        memcpy((frameBuf + mFrameBufOffset), nalBuf, bufSize);
        mFrameBufOffset = mFrameBufOffset + bufSize;
    }
    else
    {
        mFrameNum = sliceHeader.iFrameNum;
        picParamBuffAmd->frameNum = mFrameNum;
        decodePoc(sliceHeader.iPpsId, sliceHeader.iSpsId, &topPoc, &bottomPoc);
        picParamBuffAmd->currFieldOrderCntList[0] = topPoc;
        picParamBuffAmd->currFieldOrderCntList[1] = bottomPoc;
        memcpy((frameBuf + mFrameBufOffset), nalBuf, bufSize);
        mFrameBufOffset = mFrameBufOffset + bufSize;
        *frameSize = mFrameBufOffset;
        *frameEndDetected = 0;
    }
    return true;
}
/**
*******************************************************************************
*  @fn     h264GetProfile
*  @brief  This function maps the profileIdc to the format required for AMD vulkan APIs
*
*  @param[in] profileIdc   : Profile IDC from H264 headers
*
*  @return bool : Returns mapped profile IDC
*******************************************************************************
*/
int h264Parse::h264GetProfile(int profileIdc)
{
    int profile = 0;
    int constraint_set_flags = 0;

    switch (profileIdc) {
    case PROFILE_H264_BASELINE:
        profile = 0;
        break;
    case PROFILE_H264_MAIN:
        profile = 1;
        break;
    case PROFILE_H264_HIGH:
        profile = 2;
        break;
    case PROFILE_H264_MULTI_VIEW1:
    case PROFILE_H264_MULTI_VIEW2:
        profile = 3;
        break;
    default:
        profile = 1;
        break;
    }

    return profile;
}
/**
*******************************************************************************
*  @fn     h264Parse
*  @brief  Constructor, Initialize and creates the AMD file/buffer interface
*
*  @param[in] iname     : Input H264 file name
*  @param[in/out] user  : Pointer to the io interface
*
*******************************************************************************
*/
h264Parse::h264Parse(char *iname, IOInterface *user)
{
    fname = new std::string(iname);
    io = user;
    ioHndl = (void *) io->open(iname, AMD_READ);

    if (ioHndl == NULL)
    {
        printf("Error in file open %s\n", iname);
    }
    firstTimeFlag = 1;
    sDecParam = { 0 };
    pos = 0;
    readLen = 0;
    mSpsId = mPpsId = 0;
    mPrevFrameNum = 0;
    mFrameBufOffset = 0;
    mNewSps = 0; mNewPps = 0;

    readBuf = (unsigned char*) malloc(SMALLBUFSIZE);

    mExpectedPicOrderCnt=0, mPicOrderCntCycleCnt=0, mFrameNumInPicOrderCntCycle=0;
    mPreviousFrameNum=0, mFrameNumOffset=0;
    mExpectedDeltaPerPicOrderCntCycle=0;
    mPreviousPOC=0, mThisPOC=0;
    mPreviousFrameNumOffset=0;
    mFramepoc=0;
    mTopPoc = 0;
    mBottomPoc = 0;
    mLastHasMmco5 = 0;
}
/**
*******************************************************************************
*  @fn     h264Parse
*  @brief  Destructor
*
*******************************************************************************
*/
h264Parse::~h264Parse()
{
    delete fname;
    if (ioHndl != NULL)
    {
        io->close(ioHndl);
    }
    free(readBuf);
}

void h264Parse::reset()
{
    io->seek(ioHndl, 0, AMD_SEEK_SET);

    readLen = pos = 0;
}
/**
*******************************************************************************
*  @fn     getNalUnit
*  @brief  This function checks for start code and returns one full NAL unit
*
*  @param[in/out] nalBuf       : Nal buffer 
*  @param[in] nalLen           : length of the nal unit
*
*  @return int : returns nal type
*******************************************************************************
*/
int h264Parse::getNalUnit(unsigned char *nalBuf, int *nalLen)
{
    int nalType;

    nalType = io->readNalu(ioHndl, (uint8*)nalBuf, nalLen);

    return nalType;

}
/**
*******************************************************************************
*  @fn     decodePoc
*  @brief  This function decodes the Picture Order Count.  
*          Presently it supports only POC type 2
*
*  @param[in] ppsId            : PPS id
*                               information buffer
*  @param[in] spsId            : Pointer to the NAL buffer
*  @param[in] topPoc           : Size of the NAL
*  @param[in/out] bottomPoc      : pointer to the complete frame(includes multiple slices)
*
*  @return bool : true if successful; otherwise false.
*******************************************************************************
*/
#include <math.h>
int h264Parse::decodePoc(unsigned int ppsId, unsigned int spsId, int *topPoc, int *bottomPoc)
{

    WelsDec::CWelsDecoder *wels = (WelsDec::CWelsDecoder *)(mPDecoder);
    WelsDec::PWelsDecoderContext ctx = wels->m_pDecContext;

    WelsDec::SSps sps = ctx->sSpsBuffer[spsId];
    WelsDec::SPps pps = ctx->sPpsBuffer[ppsId];
    WelsDec::SSliceHeader sliceHeader = *ctx->pSliceHeader;

    mNalRefIdc = 1;
    // for POC mode 0:
    int MaxPicOrderCntLsb = (1 << (sps.iLog2MaxPocLsb));
    switch (sps.uiPocType)
    {
        printf("not supported\n");
        return -1;
        break;
    case 1: // POC MODE 1
        // 1st
        printf("not supported\n");
        return -1;
        break;
    case 2: // POC MODE 2
        if (sliceHeader.bIdrFlag) // IDR picture
        {
            mFrameNumOffset = 0;     //  first pix of IDRGOP,
            mThisPOC = mFramepoc = mTopPoc = mBottomPoc = 0;
            if (sliceHeader.iFrameNum)
            {
                printf("frame_num not equal to zero in IDR picture\n");
                return -1;
            }
        }
        else
        {
            if (mLastHasMmco5)
            {
                mPreviousFrameNum = 0;
                mPreviousFrameNumOffset = 0;
            }
            if (sliceHeader.iFrameNum < (int)mPreviousFrameNum)
                mFrameNumOffset = mPreviousFrameNumOffset + (int)pow(2.0,(float)sps.uiLog2MaxFrameNum);
            else
                mFrameNumOffset = mPreviousFrameNumOffset;
            mAbsFrameNum = mFrameNumOffset + sliceHeader.iFrameNum;
            if (!mNalRefIdc)
                mThisPOC = (2 * mAbsFrameNum - 1);
            else
                mThisPOC = (2 * mAbsFrameNum);
            if (sliceHeader.bFieldPicFlag == 0)
                mTopPoc = mBottomPoc = mFramepoc = mThisPOC;
            else if (sliceHeader.bBottomFiledFlag == 0)
                mTopPoc = mFramepoc = mThisPOC;
            else 
                mBottomPoc = mFramepoc = mThisPOC;
        }
        mPreviousFrameNum = sliceHeader.iFrameNum;
        mPreviousFrameNumOffset = mFrameNumOffset;
        break;
    default:
        //error must occurs
        assert(1 == 0);
        break;
    }
    mLastHasMmco5 = sliceHeader.sRefMarking.sMmcoRef[0].uiMmcoType;
    *topPoc = mTopPoc;
    *bottomPoc = mBottomPoc;

    return true;
}

