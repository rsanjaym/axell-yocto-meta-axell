/*******************************************************************************
 Copyright �2014 Advanced Micro Devices, Inc. All rights reserved.

 Redistribution and use in source and binary forms, with or without 
 modification, are permitted provided that the following conditions are met:

 1   Redistributions of source code must retain the above copyright notice, 
 this list of conditions and the following disclaimer.
 2   Redistributions in binary form must reproduce the above copyright notice, 
 this list of conditions and the following disclaimer in the 
 documentation and/or other materials provided with the distribution.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE 
 LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
 THE POSSIBILITY OF SUCH DAMAGE.
 *******************************************************************************/
/**
 ********************************************************************************
 * @file <amdInterface.h>
 *
 * @brief Defines constants and enums used in amdInterface
 *
 ********************************************************************************
 */
#pragma once

#ifndef _AMDINTERFACE_H_
#define _AMDINTERFACE_H_

#include <memory.h>

#define READBUFSIZE		1024

/*! \struct ioHandle
    \brief handle to the I/O context

    This structure stores the context to the I/O handle
*/
typedef struct _ioHandle
{
	FILE *fp;
	int32 m_bufPos, m_readLen;
	uint8 m_readBuf[READBUFSIZE];
}ioHandle;

/*! \class amdInterface
    \brief Pure virtual methods for input and  output handling

    This class contains all the I/O interface functions 
 */
class amdInterface : public IOInterface
{
public:
    /**
    *******************************************************************************
    * @fn open
    * @brief Function to open a flie in write mode
    *
    * @param[in] sourceName : int8 * :   Name of the source being opened
    * @param[in] ioMode : AMDIO_MODE :   mode of the I/O device to open
    *
    * @return void * I/O device handle
    *******************************************************************************
    */
    void *open(int8 *sourceName, AMDIO_MODE ioMode)
    {
        int8 *mode;
        switch(ioMode)
        {
        case AMD_READ:
            mode = (int8 *)"rb";
            break;
        case AMD_WRITE:
            mode = (int8 *)"wb";
            break;
        case AMD_APPEND:
            mode = (int8 *)"ab";
            break;
        default:
            return NULL;
        }

        ioHandle *hndl = new ioHandle;
        hndl->m_bufPos = 0;
        hndl->m_readLen = 0;
        hndl->fp = fopen(sourceName, mode);

        if(hndl->fp == NULL)
        {
            hndl = NULL;
        }
        return (void *) hndl;
    }

    /*******************************************************************************
	* @fn readNalu
	* @brief Function to read one nal unit from I/O Device
	*
	* @param[in] pHandle : void * :  amd I/O handle
	* @param[in] nalBuf : void * :     pointer to the nal buffer
	* @param[out] nalSize : int32 * :    size of the returned nal-unit in bytes
	*
	* @returns nal_unit_type
	*******************************************************************************
	*/
	int32 readNalu(void *pHandle, uint8 *nalBuf, int32 *nalSize)
	{
		int32 nalType;

		int32 offset = 0;

		ioHandle *hndl = (ioHandle *)pHandle;
		uint8 *readBuf = hndl->m_readBuf;

		bool endLoop = false;

		while (!endLoop)
		{
			if (0 == hndl->m_readLen)
			{
				int32 retVal = (int) fread(&readBuf[hndl->m_bufPos], 1,
								(READBUFSIZE - hndl->m_bufPos), (FILE*)hndl->fp);

				hndl->m_readLen = hndl->m_bufPos + retVal;

				if (hndl->m_readLen <= 4)
				{
					if (offset > 4)
					{
						endLoop = true;
						if(hndl->m_readLen > 0)
						{
							memcpy(&nalBuf[offset], &readBuf[hndl->m_bufPos], hndl->m_readLen);
							offset += hndl->m_readLen;
						}
						hndl->m_readLen = 0;
						break;
					}
					else
					{
						*nalSize = 0;
						hndl->m_readLen = 0;
						return -1;
					}
				}

				if (0 == retVal)
				{
					endLoop = true;
				}

				hndl->m_bufPos = 0;
			}

			int32 zeros = 0;

			do
			{
				uint8 readVal;

				readVal = readBuf[hndl->m_bufPos++];
				nalBuf[offset++] = readVal;

				if (readVal == 0)
				{
					zeros++;
				}
				else
				{
					if ((zeros >= 2) && (readVal == 1))
					{
						if (offset > 4)
						{
							hndl->m_bufPos -= 4; //(zeros + 1);
							offset -= 4; //(zeros + 1);
							endLoop = true;
							break;
						}
					}
					zeros = 0;
				}

			} while ((hndl->m_bufPos + 4) < hndl->m_readLen);

			if ((zeros > 0) && (!endLoop))
			{
				 if(zeros >= 3)
					zeros = 3;
				 hndl->m_bufPos -= zeros;
				offset -= zeros;
			}

			if ((hndl->m_bufPos + 7) >= hndl->m_readLen)
			{
				memcpy(readBuf, &readBuf[hndl->m_bufPos], (hndl->m_readLen - hndl->m_bufPos));
				hndl->m_bufPos = hndl->m_readLen - hndl->m_bufPos;
				hndl->m_readLen = 0;
			}
		}

		nalType = *((uint8 *)nalBuf + 4) & 0x1F;

		*nalSize = offset;

		//printf("Type %d Size %d\n", nalType, *nalSize);

		return nalType;
	}

    /**
    *******************************************************************************
    * @fn seek
    * @brief Function to seek from I/O Device origin
    *
    * @param[in] pHandle : void * :  amd I/O handle
    * @param[in] offset : int64 :   Number of bytes to offset from origin.
    * @param[in] origin : AMDIO_ORIGIN :    Position used as reference for the offset. 
    *
    * @return If successful, the function returns zero.
    * Otherwise, it returns non-zero value.
    *******************************************************************************
    */
    int32 seek(void *pHandle, int64  offset, AMDIO_ORIGIN ioOrigin)
    {
        int32 origin;
        ioHandle *hndl = (ioHandle *)pHandle;

        switch(ioOrigin)
        {
        case AMD_SEEK_SET:
            origin = SEEK_SET;
            break;
        case AMD_SEEK_CUR:
            origin = SEEK_CUR;
            break;
        case AMD_SEEK_END:
            origin = SEEK_END;
            break;
        default :
            return -1;
        }

        hndl->m_bufPos = 0;
        hndl->m_readLen = 0;

        return fseek((FILE *) hndl->fp, (long)offset, origin);
    }

    /**
    *******************************************************************************
    * @fn eod
    * @brief Checks whether the end-of-data indicator associated with I/O device
    *
    * @param[in] pHandle : void * :  amd I/O handle
    *
    * @return A non-zero value is returned in the case that the end-of-data indicator
    *associated with the I/O device is set.Otherwise, zero is returned.
    *******************************************************************************
    */
    int32 eod(void *pHandle)
    {
    	ioHandle *hndl = (ioHandle *)pHandle;
        if(!feof((FILE*) hndl->fp))
        {
            return 0;
        }
        else
        {
            return EOD;
        }    
    }

    /**
    *******************************************************************************
    * @fn close
    * @brief Function to close the I/O device
    *
    * @param[in] pHandle : void * :  amd I/O handle
    *
    * @return If the I/O device  is successfully closed, a zero value is returned.
    *  On failure, EOD is returned.
    *******************************************************************************
    */
    int32 close(void *pHandle)
    {
    	ioHandle *hndl = (ioHandle *)pHandle;
    	int32 retVal = fclose(hndl->fp);
    	delete hndl;

        return retVal;
    }
};
#endif /* _AMDINTERFACE_H_ */
