/*
 ***********************************************************************************************************************
 *
 *  Trade secret of Advanced Micro Devices, Inc.
 *  Copyright (c) 2014-2016, Advanced Micro Devices, Inc., (unpublished)
 *
 *  All rights reserved. This notice is intended as a precaution against inadvertent publication and does not imply
 *  publication or any waiver of confidentiality. The year included in the foregoing notice is the year of creation of
 *  the work.
 *
 **********************************************************************************************************************/
/**
 **********************************************************************************************************************
 * @file  vk_amd_video_encode_queue.h
 * @brief Temporary internal header for VCE extension. Should be removed once the extension is published and the API
 *        gets included in the official Vulkan header.
 **********************************************************************************************************************
 */
#ifndef VK_AMD_VIDEO_ENCODE_QUEUE_H_
#define VK_AMD_VIDEO_ENCODE_QUEUE_H_

#include "vk_internal_ext_helper.h"

#define VK_AMD_VIDEO_ENCODE_QUEUE_SPEC_VERSION              1
#define VK_AMD_VIDEO_ENCODE_QUEUE_EXTENSION_NAME            "VK_AMD_video_encode_queue"

#define VK_AMD_VIDEO_ENCODE_QUEUE_EXTENSION_NUMBER          24

#define VK_AMD_VIDEO_ENCODE_QUEUE_ENUM(type, offset) \
    VK_EXTENSION_ENUM(VK_AMD_VIDEO_ENCODE_QUEUE_EXTENSION_NUMBER, type, offset)

typedef enum VkVideoProfileAMD
{
    VK_VIDEO_PROFILE_MPEG4_AVC_CONSTRAINED_BASELINE_AMD = 0,
    VK_VIDEO_PROFILE_MPEG4_AVC_MAIN_AMD = 1,
    VK_VIDEO_PROFILE_MPEG4_AVC_HIGH_AMD = 2,
    VK_VIDEO_PROFILE_BEGIN_RANGE_AMD = VK_VIDEO_PROFILE_MPEG4_AVC_CONSTRAINED_BASELINE_AMD,
    VK_VIDEO_PROFILE_END_RANGE_AMD = VK_VIDEO_PROFILE_MPEG4_AVC_HIGH_AMD,
    VK_VIDEO_PROFILE_RANGE_SIZE_AMD = (VK_VIDEO_PROFILE_END_RANGE_AMD - VK_VIDEO_PROFILE_BEGIN_RANGE_AMD + 1),
    VK_VIDEO_PROFILE_MAX_ENUM_AMD = 0x7FFFFFFF
} VkVideoProfileAMD;

typedef enum VkVideoEncodeRateControlMethodAMD
{
    VK_VIDEO_ENCODE_RATE_CONTROL_METHOD_CONSTANT_QP_AMD = 0,
    VK_VIDEO_ENCODE_RATE_CONTROL_METHOD_CONSTANT_BITRATE_AMD = 1,
    VK_VIDEO_ENCODE_RATE_CONTROL_METHOD_PEAK_CONSTRAINED_VARIABLE_BITRATE_AMD = 2,
    VK_VIDEO_ENCODE_RATE_CONTROL_METHOD_LATENCY_CONSTRAINED_VARIABLE_BITRATE_AMD = 3,
    VK_VIDEO_ENCODE_RATE_CONTROL_METHOD_BEGIN_RANGE_AMD = VK_VIDEO_ENCODE_RATE_CONTROL_METHOD_CONSTANT_QP_AMD,
    VK_VIDEO_ENCODE_RATE_CONTROL_METHOD_END_RANGE_AMD = VK_VIDEO_ENCODE_RATE_CONTROL_METHOD_LATENCY_CONSTRAINED_VARIABLE_BITRATE_AMD,
    VK_VIDEO_ENCODE_RATE_CONTROL_METHOD_RANGE_SIZE_AMD = (VK_VIDEO_ENCODE_RATE_CONTROL_METHOD_END_RANGE_AMD - VK_VIDEO_ENCODE_RATE_CONTROL_METHOD_BEGIN_RANGE_AMD + 1),
    VK_VIDEO_ENCODE_RATE_CONTROL_METHOD_MAX_ENUM_AMD = 0x7FFFFFFF
} VkVideoEncodeRateControlMethodAMD;

typedef enum VkVideoFrameTypeAMD
{
    VK_VIDEO_FRAME_TYPE_P_AMD = 0,
    VK_VIDEO_FRAME_TYPE_B_AMD = 1,
    VK_VIDEO_FRAME_TYPE_I_AMD = 2,
    VK_VIDEO_FRAME_TYPE_IDR_AMD = 3,
    VK_VIDEO_FRAME_TYPE_SKIP_AMD = 4,
    VK_VIDEO_FRAME_TYPE_BEGIN_RANGE_AMD = VK_VIDEO_FRAME_TYPE_P_AMD,
    VK_VIDEO_FRAME_TYPE_END_RANGE_AMD = VK_VIDEO_FRAME_TYPE_SKIP_AMD,
    VK_VIDEO_FRAME_TYPE_RANGE_SIZE_AMD = (VK_VIDEO_FRAME_TYPE_END_RANGE_AMD - VK_VIDEO_FRAME_TYPE_BEGIN_RANGE_AMD + 1),
    VK_VIDEO_FRAME_TYPE_MAX_ENUM_AMD = 0x7FFFFFFF
} VkVideoFrameTypeAMD;

typedef enum VkPictureOrderCountTypeAMD
{
    VK_PICTURE_ORDER_COUNT_TYPE_DERIVED_AMD = 0,
    VK_PICTURE_ORDER_COUNT_TYPE_EXPLICIT_AMD = 1,
    VK_PICTURE_ORDER_COUNT_TYPE_BEGIN_RANGE_AMD = VK_PICTURE_ORDER_COUNT_TYPE_DERIVED_AMD,
    VK_PICTURE_ORDER_COUNT_TYPE_END_RANGE_AMD = VK_PICTURE_ORDER_COUNT_TYPE_EXPLICIT_AMD,
    VK_PICTURE_ORDER_COUNT_TYPE_RANGE_SIZE_AMD = (VK_PICTURE_ORDER_COUNT_TYPE_END_RANGE_AMD - VK_PICTURE_ORDER_COUNT_TYPE_BEGIN_RANGE_AMD + 1),
    VK_PICTURE_ORDER_COUNT_TYPE_MAX_ENUM_AMD = 0x7FFFFFFF
} VkPictureOrderCountTypeAMD;

typedef enum VkMotionEstimationPresetAMD
{
    VK_MOTION_ESTIMATION_PRESET_SPEED_AMD = 0,
    VK_MOTION_ESTIMATION_PRESET_BALANCED_AMD = 1,
    VK_MOTION_ESTIMATION_PRESET_QUALITY_AMD = 2,
    VK_MOTION_ESTIMATION_PRESET_BEGIN_RANGE_AMD = VK_MOTION_ESTIMATION_PRESET_SPEED_AMD,
    VK_MOTION_ESTIMATION_PRESET_END_RANGE_AMD = VK_MOTION_ESTIMATION_PRESET_QUALITY_AMD,
    VK_MOTION_ESTIMATION_PRESET_RANGE_SIZE_AMD = (VK_MOTION_ESTIMATION_PRESET_END_RANGE_AMD - VK_MOTION_ESTIMATION_PRESET_BEGIN_RANGE_AMD + 1),
    VK_MOTION_ESTIMATION_PRESET_MAX_ENUM_AMD = 0x7FFFFFFF
} VkMotionEstimationPresetAMD;

struct VkVideoEncodePropertiesAMD
{
    uint32_t                            maxLevel;                               // Maximum codec profile level (encoded using VK_MAKE_VERSION)

    VkExtent2D                          minFrameSize;                           // Minimum frame size
    VkExtent2D                          maxFrameSize;                           // Maximum frame size
    uint64_t                            maxFrameSamples;                        // Maximum number of pixels per frame (product of width and height must not exceed this)

    uint64_t                            minBitrate;                             // Minimum target/peak bitrate
    uint64_t                            maxBitrate;                             // Maximum target/peak bitrate

    uint32_t                            minQP;                                  // Minimum quantization parameter
    uint32_t                            maxQP;                                  // Maximum quantization parameter
    int32_t                             minDeltaQP;                             // Minimum quantization parameter delta
    int32_t                             maxDeltaQP;                             // Maximum quantization parameter delta

    float                               minFrameRate;                           // Minimum frame rate
    float                               maxFrameRate;                           // Maximum frame rate

    uint64_t                            minVBVBufferSize;                       // Minimum VBV buffer size in bits
    uint64_t                            maxVBVBufferSize;                       // Maximum VBV buffer size in bits

    uint32_t                            maxBackwardReferenceFrames;             // Maximum number of backward reference frames
    uint32_t                            maxForwardReferenceFrames;              // Maximum number of forward reference frames
    uint32_t                            maxTotalReferenceFrames;                // Maximum number of total reference frames
};

struct VkVideoEncodePipelineCreateInfoAMD
{
    VkStructureType                     sType;
    const void*                         pNext;

    VkPipelineCreateFlags               flags;

    VkVideoProfileAMD                   profile;                                // Codec profile
    uint32_t                            level;                                  // Codec level

    VkFormat                            imageFormat;                            // Source image format
    VkImageTiling                       imageTiling;                            // Source image tiling
    VkExtent2D                          frameSize;                              // Width and height of frames

    uint32_t                            maxDPBFrames;                           // Maximum number of frames that can be kept in the DPB
                                                                                // The number of reference frames that can be kept in the DPB equals maxDPBFrames-1
                                                                                // Value must respect profile and level implied DPB limit

    VkMotionEstimationPresetAMD         motionEstimationPreset;                 // Motion estimation preset

    VkPipeline                          basePipelineHandle;
    int32_t                             basePipelineIndex;
};

struct VkVideoEncodeBeginInfoAMD
{
    VkStructureType                     sType;
    const void*                         pNext;
};

struct VkVideoEncodeRateControlAMD
{
    VkStructureType                     sType;
    const void*                         pNext;

    VkVideoEncodeRateControlMethodAMD   method;                                 // Rate control method

    uint64_t                            targetBitrate;                          // Target bitrate (10000..100000000)
    uint64_t                            peakBitrate;                            // Peak bitrate (10000..100000000)

    float                               frameRate;                              // Rate control frame rate

    bool                                skipFrameEnable;                        // Enable using skip frames for rate control

    uint32_t                            minQP;                                  // Minimum QP (0..51)
    uint32_t                            maxQP;                                  // Maximum QP (0..51)

    uint32_t                            IFrameQP;                               // Constant QP for I-frames (0..51)
    uint32_t                            PFrameQP;                               // Constant QP for P-frames (0..51)
    uint32_t                            BFrameQP;                               // Constant QP for B-frames (0..51)

    int32_t                             BFrameDeltaQP;                          // Delta QP of non-reference B frames with respect to I frames (-10..10)
    int32_t                             referenceBFrameDeltaQP;                 // Delta QP of reference B frames with respect to I frames (-10..10)

    uint64_t                            VBVBufferSize;                          // VBV buffer size in bits (1000..100000000)
    float                               VBVBufferLevel;                         // Initial VBV buffer fullness ratio
};

struct VkVideoEncodeFrameControlAMD
{
    VkStructureType                     sType;
    const void*                         pNext;

    uint32_t                            maxFrameReferences;                     // Maximum number of frames another frame may reference (setting to 1 disables B-frames)

    uint32_t                            maxDecoderReferenceFrames;              // Maximum number of reference frames that should be kept around by the decoder

    VkPictureOrderCountTypeAMD          pictureOrderCountType;                  // Type of POC
    uint32_t                            maxPictureOrderCountLSB;                // MaxPicOrderCntLsb of the sequence
};

struct VkVideoFrameDescriptionAMD
{
    VkVideoFrameTypeAMD                 frameType;                              // Video frame type
    uint32_t                            frameNumber;                            // Frame number (reference frame index)
    uint32_t                            pictureOrderCount;                      // POC of the frame (display order index)

    uint32_t                            DPBFrameIndex;                          // Index (location) of the frame in the encoder DPB
};

struct VkRateControlWindowInfoAMD
{
    uint32_t                            remainingIFrames;                       // Number of remaining I/IDR frames in the rate control window
    uint32_t                            remainingPFrames;                       // Number of remaining P frames in the rate control window
    uint32_t                            remainingBFrames;                       // Number of remaining B frames in the rate control window
};

struct VkVideoEncodeFrameInfoAMD
{
    VkStructureType                     sType;
    const void*                         pNext;

    VkVideoFrameDescriptionAMD          frameDescription;                       // Essential information about the frame
    bool                                reference;                              // Tells whether this frame can be used as reference

    uint32_t                            backwardReferenceFrameCount;            // Number of backward reference frames
    const VkVideoFrameDescriptionAMD*   pBackwardReferenceFrames;               // Backward reference frame descriptions

    uint32_t                            forwardReferenceFrameCount;             // Number of forward reference frames
    const VkVideoFrameDescriptionAMD*   pForwardReferenceFrames;                // Forward reference frame descriptions

    uint32_t                            frameCounter;                           // Free-run counter, increment on every frame, wrap after 0xFFFFFFFF
    bool                                endOfSequence;                          // This frame is the last in a sequence
    bool                                endOfStream;                            // This frame is the last in the stream

    VkRateControlWindowInfoAMD          rateControlWindow;                      // Information about rate control window

    VkImage                             srcImage;                               // Source image

    VkBuffer                            dstBuffer;                              // Destination buffer
    VkDeviceSize                        dstOffset;                              // Destination offset
    VkDeviceSize                        dstRange;                               // Maximum allowed encoded output frame size

    VkQueryPool                         queryPool;                              // Video encode feedback query pool to use
    uint32_t                            queryIndex;                             // Query index to which feedback should be written
};

typedef void (VKAPI_PTR *PFN_vkGetPhysicalDeviceVideoEncodePropertiesAMD)(VkPhysicalDevice physicalDevice, uint32_t queueFamilyIndex, const VkVideoProfileAMD* pProfile, const uint32_t* pLevel, VkVideoEncodePropertiesAMD* pProperties);

VKAPI_ATTR void VKAPI_CALL vkGetPhysicalDeviceVideoEncodePropertiesAMD(
    VkPhysicalDevice                            physicalDevice,
    uint32_t                                    queueFamilyIndex,
    const VkVideoProfileAMD*                    pProfile,
    const uint32_t*                             pLevel,
    VkVideoEncodePropertiesAMD*                 pProperties);

typedef VkResult (VKAPI_PTR *PFN_vkCreateVideoEncodePipelinesAMD)(VkDevice device, VkPipelineCache pipelineCache, uint32_t createInfoCount, const VkVideoEncodePipelineCreateInfoAMD* pCreateInfos, const VkAllocationCallbacks* pAllocator, VkPipeline* pPipelines);

VKAPI_ATTR VkResult VKAPI_CALL vkCreateVideoEncodePipelinesAMD(
    VkDevice                                    device,
    VkPipelineCache                             pipelineCache,
    uint32_t                                    createInfoCount,
    const VkVideoEncodePipelineCreateInfoAMD*   pCreateInfos,
    const VkAllocationCallbacks*                pAllocator,
    VkPipeline*                                 pPipelines);

typedef void (VKAPI_PTR *PFN_vkCmdBeginVideoEncodeAMD)(VkCommandBuffer cmdBuffer, const VkVideoEncodeBeginInfoAMD* pBeginInfo);

VKAPI_ATTR void VKAPI_CALL vkCmdBeginVideoEncodeAMD(
    VkCommandBuffer                             cmdBuffer,
    const VkVideoEncodeBeginInfoAMD*            pBeginInfo);

typedef void (VKAPI_PTR *PFN_vkCmdSetVideoEncodeFrameControlAMD)(VkCommandBuffer cmdBuffer, const VkVideoEncodeFrameControlAMD* pFrameControl);

VKAPI_ATTR void VKAPI_CALL vkCmdSetVideoEncodeFrameControlAMD(
    VkCommandBuffer                             cmdBuffer,
    const VkVideoEncodeFrameControlAMD*         pFrameControl);

typedef void (VKAPI_PTR *PFN_vkCmdSetVideoEncodeRateControlAMD)(VkCommandBuffer cmdBuffer, const VkVideoEncodeRateControlAMD* pRateControl);

VKAPI_ATTR void VKAPI_CALL vkCmdSetVideoEncodeRateControlAMD(
    VkCommandBuffer                             cmdBuffer,
    const VkVideoEncodeRateControlAMD*          pRateControl);

typedef void (VKAPI_PTR *PFN_vkCmdEncodeVideoFrameAMD)(VkCommandBuffer cmdBuffer, const VkVideoEncodeFrameInfoAMD* pFrameInfo);

VKAPI_ATTR void VKAPI_CALL vkCmdEncodeVideoFrameAMD(
    VkCommandBuffer                             cmdBuffer,
    const VkVideoEncodeFrameInfoAMD*            pFrameInfo);

typedef void (VKAPI_PTR *PFN_vkCmdEndVideoEncodeAMD)(
    VkCommandBuffer                             cmdBuffer);

VKAPI_ATTR void VKAPI_CALL vkCmdEndVideoEncodeAMD(
    VkCommandBuffer                             cmdBuffer);

#define VK_STRUCTURE_TYPE_VIDEO_ENCODE_PIPELINE_CREATE_INFO_AMD VK_AMD_VIDEO_ENCODE_QUEUE_ENUM(VkStructureType, 0)
#define VK_STRUCTURE_TYPE_VIDEO_ENCODE_BEGIN_INFO_AMD           VK_AMD_VIDEO_ENCODE_QUEUE_ENUM(VkStructureType, 1)
#define VK_STRUCTURE_TYPE_VIDEO_ENCODE_FRAME_INFO_AMD           VK_AMD_VIDEO_ENCODE_QUEUE_ENUM(VkStructureType, 2)
#define VK_STRUCTURE_TYPE_VIDEO_ENCODE_RATE_CONTROL_AMD         VK_AMD_VIDEO_ENCODE_QUEUE_ENUM(VkStructureType, 3)
#define VK_STRUCTURE_TYPE_VIDEO_ENCODE_FRAME_CONTROL_AMD        VK_AMD_VIDEO_ENCODE_QUEUE_ENUM(VkStructureType, 4)

#define VK_PIPELINE_BIND_POINT_VIDEO_ENCODE_AMD                 VK_AMD_VIDEO_ENCODE_QUEUE_ENUM(VkPipelineBindPoint, 0)

#define VK_QUERY_TYPE_VIDEO_ENCODE_AMD                          VK_AMD_VIDEO_ENCODE_QUEUE_ENUM(VkQueryType, 0)

#define VK_FORMAT_FEATURE_VIDEO_ENCODE_SRC_BIT_AMD              VK_EXTENSION_BIT(VkFormatFeatureFlagBits, 14)

#define VK_QUEUE_VIDEO_ENCODE_BIT_AMD                           VK_EXTENSION_BIT(VkQueueFlagBits, 4)

#define VK_PIPELINE_STAGE_VIDEO_ENCODE_BIT_AMD                  VK_EXTENSION_BIT(VkPipelineStageFlagBits, 17)

#define VK_ACCESS_VIDEO_ENCODE_READ_BIT_AMD                     VK_EXTENSION_BIT(VkAccessFlagBits, 17)
#define VK_ACCESS_VIDEO_ENCODE_WRITE_BIT_AMD                    VK_EXTENSION_BIT(VkAccessFlagBits, 18)

#define VK_BUFFER_USAGE_VIDEO_ENCODE_DST_BIT_AMD                VK_EXTENSION_BIT(VkBufferUsageFlagBits, 9)

#define VK_IMAGE_USAGE_VIDEO_ENCODE_SRC_BIT_AMD                 VK_EXTENSION_BIT(VkImageUsageFlagBits, 8)

#endif /* VK_AMD_VIDEO_ENCODE_QUEUE_H_ */
