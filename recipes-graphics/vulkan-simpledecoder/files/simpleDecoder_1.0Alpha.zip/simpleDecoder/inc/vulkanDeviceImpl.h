﻿/*******************************************************************************
Copyright �2016 Advanced Micro Devices, Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1   Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.
2   Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.
*******************************************************************************/
#ifndef VULKAN_DEVICE_IMPL_H_
#define VULKAN_DEVICE_IMPL_H_
#include "vulkan.h"
#include <memory>
#include <map>
#include <vector>
//#include "utilsVK.h"
#include "macros.h"
#include "vk_amd_yuv_image.h"


#define VK_EXTENSION_ENUM(extnr, type, offset) ((type)(VK_EXTENSION_ENUM_BASE_VALUE + (((extnr)-1) * VK_EXTENSION_ENUM_RANGE_SIZE) + (offset)))
#define VK_EXTENSION_BIT(type, bit)            ((type)(1 << (bit)))
#define VK_EXTENSION_ENUM(extnr, type, offset) ((type)(VK_EXTENSION_ENUM_BASE_VALUE + (((extnr)-1) * VK_EXTENSION_ENUM_RANGE_SIZE) + (offset)))
/* <-- */

/* VK_AMD_YUV_image extension stuff --> */
//#define VK_AMD_YUV_IMAGE_EXTENSION_NUMBER   17
//#define VK_AMD_YUV_IMAGE_ENUM(type, offset) VK_EXTENSION_ENUM(VK_AMD_YUV_IMAGE_EXTENSION_NUMBER, type, offset)
//#define VK_FORMAT_NV12_AMD                  VK_AMD_YUV_IMAGE_ENUM(VkFormat, 0)
/* <-- */

/* VK_AMD_video_decode_queue extension stuff --> */
#define VK_AMD_VIDEO_DECODE_QUEUE_EXTENSION_NUMBER              25
#define VK_AMD_VIDEO_DECODE_QUEUE_ENUM(type, offset)            VK_EXTENSION_ENUM(VK_AMD_VIDEO_DECODE_QUEUE_EXTENSION_NUMBER, type, offset)
#define VK_PIPELINE_BIND_POINT_VIDEO_DECODE_AMD                 VK_AMD_VIDEO_DECODE_QUEUE_ENUM(VkPipelineBindPoint, 0)
#define VK_QUEUE_VIDEO_DECODE_BIT_AMD                           VK_EXTENSION_BIT(VkQueueFlagBits, 5)
#define VK_STRUCTURE_TYPE_VIDEO_DECODE_PIPELINE_CREATE_INFO_AMD VK_AMD_VIDEO_DECODE_QUEUE_ENUM(VkStructureType, 0)
#define VK_STRUCTURE_TYPE_VIDEO_DECODE_BEGIN_INFO_AMD           VK_AMD_VIDEO_DECODE_QUEUE_ENUM(VkStructureType, 1)
#define VK_STRUCTURE_TYPE_VIDEO_DECODE_FRAME_INFO_AMD           VK_AMD_VIDEO_DECODE_QUEUE_ENUM(VkStructureType, 2)

#define MAX_UNSIGNEDINT      0xffffffff    /* maximum unsigned int value */





class VulkanDeviceImpl
{
public :
    VkDevice mVulkanDevice;
    VkInstance mVulkanInstance;
    VkPhysicalDevice mVulkanPhisicalDevice;
    std::map<VkQueueFlags, std::vector<VkQueue> >  mQueues;
    bool init();
    void getNativeDevice();
    VulkanDeviceImpl();
    struct vulkanSurface
    {
        vulkanSurface() :
        hImage(nullptr),
        hMemory(nullptr),
        hSize(0),
        width(0),
        height(0),
        format(0)
        {}
        VkImage         hImage;
        VkDeviceMemory  hMemory;
        VkDeviceSize    hSize;
        int       format;
        int       width;
        int       height;
        int       width_pitch;
        int       height_pitch;
    };
    struct vulkanBuffer
    {
        vulkanBuffer() :
        mBuffer(nullptr),
        mMemory(nullptr),
        mSize(0L)
        {}
        VkBuffer        mBuffer;
        VkDeviceMemory  mMemory;
        VkDeviceSize    mSize;
    };

    unsigned int mUniQueueIndex;
    unsigned int mDecodeQueueIndex;
    bool createInstance(VkInstance *vulkanInstance);
    bool createVkDeviceAndQueues();
    bool createCommandPool(int familyIndex, VkCommandPool *commandPool);
    bool createPipelineCache(VkPipelineCache* outputPipelineCache);
    bool createCommandBuffer(VkCommandPool hPool, VkCommandBuffer* pCmdBuffer);
    bool createVulkanSurface(vulkanSurface *vulkanSufPtr, VkFormat format, int numPlanes, int width, int height);
    bool allocateVulkanMemory(const VkMemoryRequirements& memoryRequirements,
        bool needsMappableMemory,
        bool needsCoherentMemory,
        VkDeviceMemory* hMemory);
    bool createBuffer(unsigned int size, vulkanBuffer* pBuffer);
    bool releaseResource();
    bool releaseSurface(vulkanSurface *pSurface);
    bool releaseBuffer(vulkanBuffer* pBuffer);
};
#endif