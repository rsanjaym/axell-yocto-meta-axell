﻿/*******************************************************************************
Copyright �2016 Advanced Micro Devices, Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1   Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.
2   Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.
*******************************************************************************/
#ifndef VULKAN_DECODE_ENGINE_H_
#define VULKAN_DECODE_ENGINE_H_
#include "vulkanDeviceImpl.h"
#include "vk_amd_video_decode_queue.h"
#include "vk_amd_yuv_image.h"
#define MAX_NUM_VIDEO_DECODE_INFO_BUF 5
#define MAX_BITSTREAM_DATA_SIZE_HD  (1800*1024*2)
#define MAX_BITSTREAM_DATA_SIZE_SD  (64*4096)
#define MAX_TARGET_QUEUE 16
#ifdef _WIN32
    #define SLEEP(time) Sleep(time)
#else
    #define SLEEP(time) usleep(time)
#endif




#define DEFAULT_DPBSIZE 6

#define GET_INSTANCE_ENTRYPOINT(i, w) w = reinterpret_cast<PFN_##w>(vkGetInstanceProcAddr(i, #w)); if(w==nullptr) return false;
#define GET_DEVICE_ENTRYPOINT(i, w) w = reinterpret_cast<PFN_##w>(vkGetDeviceProcAddr(i, #w)); if(w==nullptr) return false;



class VulkanDecodeEngine : public VulkanDeviceImpl
{
public:
    bool initDecodeEngine(int width, int height, int numTargetBuffers);
    int h264GetProfile(int profileIdc);
    bool beginDecodeFrame(unsigned char* input, unsigned int inputSize,
        VkVideoDecodeH264PictureParametersBufferAMD *videoInfoBuf, 
        int targetBuffId);
    bool endDecodeFrame(int targetBuffId);
    bool waitForDecodeToComplete(int targetBuffId);
    VulkanDecodeEngine();
    bool dumpOutput(FILE *foutput,int targetBuffId);
    bool destroy(int numTargetBuffers);
private:
    
    bool createVulkanDecodeInfoBuffersH264();
    bool createVulkanDecodeBuffers(int width, int height, int numTargetBuffers);
    bool createDecodeSession();
    bool loadVulkanExtFunction();
    bool copyVideoInfoBuffer(VkVideoDecodeH264PictureParametersBufferAMD *videoInfoBuf);
    bool copyBitstream(unsigned char* input, unsigned int inputSize, int targetBuffId);
    
    VkCommandPool                      mDecodeCommandPool;
    VkPipeline                         mDecodePipeline;
    bool                               mPipelineInitialized;
    VkPipelineCache                    mPipelineCache;
    VkCommandBuffer                    mCmdBuffer;
    bool                               mDecodePipelineInitialized;
    int mWidth, mHeight;
    

    struct VulkanTarget {
        VulkanTarget() :
        mWaitFence(VK_NULL_HANDLE),
        mBitstreamBuffer(NULL),
        mPSurfaceVk(NULL)
        {
            mPSurfaceVk = new(vulkanSurface);
            mBitstreamBuffer = new(vulkanBuffer);
        }

        ~VulkanTarget()
        {
            if (mPSurfaceVk != NULL)
                mPSurfaceVk = NULL;
        }
        vulkanSurface* mPSurfaceVk;       // Vulkan surface
        VkFence     mWaitFence;
        bool        mIsFenceSubmitted;
        // We have to allocate bitstream buffer for each frame because 
        // mm driver doesn't copy slices into internal memory    
        vulkanBuffer    *mBitstreamBuffer;
        unsigned int    mBitstreamSize;
    };
    VulkanTarget mDecoderTarget[MAX_TARGET_QUEUE];
    int mNumVideoDecodeInfoBuffers;
    VkVideoDecodeInfoAMD *mPVideoDecodeInfoBuf[MAX_NUM_VIDEO_DECODE_INFO_BUF];
    VkVideoDecodeInfoAMD *mPPicParamsBuffer;

    PFN_vkGetPhysicalDeviceSurfaceSupportKHR      vkGetPhysicalDeviceSurfaceSupportKHR;
    PFN_vkGetPhysicalDeviceSurfaceCapabilitiesKHR vkGetPhysicalDeviceSurfaceCapabilitiesKHR;
    PFN_vkGetPhysicalDeviceSurfaceFormatsKHR      vkGetPhysicalDeviceSurfaceFormatsKHR;
    PFN_vkGetPhysicalDeviceSurfacePresentModesKHR vkGetPhysicalDeviceSurfacePresentModesKHR;

    PFN_vkCreateSwapchainKHR    vkCreateSwapchainKHR;
    PFN_vkDestroySwapchainKHR   vkDestroySwapchainKHR;
    PFN_vkGetSwapchainImagesKHR vkGetSwapchainImagesKHR;
    PFN_vkAcquireNextImageKHR   vkAcquireNextImageKHR;
    PFN_vkQueuePresentKHR       vkQueuePresentKHR;

    PFN_vkCreateVideoDecodePipelinesAMD vkCreateVideoDecodePipelinesAMD;
    PFN_vkCmdBeginVideoDecodeAMD        vkCmdBeginVideoDecodeAMD;
    PFN_vkCmdDecodeVideoFrameAMD        vkCmdDecodeVideoFrameAMD;
    PFN_vkCmdEndVideoDecodeAMD          vkCmdEndVideoDecodeAMD;

};
#endif